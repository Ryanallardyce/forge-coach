package uk.co.forgecoach;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(14,22,22), CARD=Color.rgb(26,37,37),
            ACCENT=Color.rgb(190,246,103), WHITE=Color.rgb(242,246,240), MUTED=Color.rgb(167,182,173), BORDER=Color.rgb(52,68,65);
    private static final int FILE_REQUEST=101;
    private LinearLayout column;
    private boolean showingWorkout=false;
    private TextView phaseLabel,nameLabel,timerLabel,cueLabel,nextLabel,overallLabel,roundLabel,blockLabel;
    private ProgressBar progress;
    private Button pauseButton;
    private int chosenWeek=1;
    private final BroadcastReceiver receiver=new BroadcastReceiver(){
        @Override public void onReceive(Context c,Intent intent){
            if(intent.hasExtra("error")) {toast(intent.getStringExtra("error"));showHome();return;}
            if(intent.getBooleanExtra("completed",false)) {
                showHome();new AlertDialog.Builder(MainActivity.this).setTitle("Workout complete")
                        .setMessage("Session saved locally. Record the weight you used, effort (RPE), and any exercise changes to inform next month's plan.")
                        .setPositiveButton("Add notes",(dialog,which)->editHistory(PlanStore.history(MainActivity.this).length()-1))
                        .setNegativeButton("Later",null).show();return;
            }
            if(WorkoutService.latest==null||!WorkoutService.latest.active){if(showingWorkout)showHome();return;}
            if(!showingWorkout)showWorkout();else refreshWorkout();
        }
    };
    @Override public void onCreate(Bundle b){super.onCreate(b);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        try{PlanStore.initialise(this);chosenWeek=PlanStore.currentWeek(PlanStore.activePlan(this));}
        catch(Exception e){new AlertDialog.Builder(this).setMessage("Unable to load included plan: "+e.getMessage()).show();}
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},200);
        }
        if(WorkoutService.latest!=null&&WorkoutService.latest.active)showWorkout();else showHome();
        // Automatic once-daily check when online. A failed check never blocks offline workouts.
        if(PlanSync.isDue(this))PlanSync.check(this,(ok,message)->{
            if(ok && !showingWorkout && !isFinishing()){
                try{chosenWeek=PlanStore.currentWeek(PlanStore.activePlan(this));}catch(Exception ignored){}
                showHome();
            }
        });
    }
    @Override protected void onStart(){super.onStart();
        IntentFilter f=new IntentFilter(WorkoutService.UPDATE);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver,f);
        if(WorkoutService.latest!=null && WorkoutService.latest.active){if(!showingWorkout)showWorkout();else refreshWorkout();}
    }
    @Override protected void onStop(){try{unregisterReceiver(receiver);}catch(Exception ignored){}super.onStop();}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);if(WorkoutService.latest!=null&&WorkoutService.latest.active)showWorkout();}

    private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+0.5f);}
    private GradientDrawable surface(int color,int stroke,int radius){
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));
        if(stroke!=0)g.setStroke(dp(1),stroke);return g;
    }
    private TextView text(String str,int size,int color,boolean bold){
        TextView v=new TextView(this);v.setText(str);v.setTextSize(size);v.setTextColor(color);
        v.setFontFeatureSettings("tnum");if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        v.setGravity(Gravity.START);return v;
    }
    private LinearLayout vbox(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout hbox(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void space(LinearLayout l,int height){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(height)));}
    private void add(LinearLayout parent,View v){parent.addView(v,new LinearLayout.LayoutParams(-1,-2));}
    private LinearLayout card(LinearLayout parent){
        LinearLayout c=vbox();c.setPadding(dp(17),dp(16),dp(17),dp(16));c.setBackground(surface(CARD,BORDER,16));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(14);parent.addView(c,lp);return c;
    }
    private Button button(String label,boolean primary){
        Button b=new Button(this);b.setText(label);b.setTextAllCaps(false);b.setTextSize(15);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setTextColor(primary?BG:WHITE);b.setBackground(surface(primary?ACCENT:Color.rgb(47,61,58),0,12));
        b.setMinHeight(dp(52));b.setPadding(dp(12),dp(10),dp(12),dp(10));return b;
    }
    private void createScreen(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        column=vbox();column.setPadding(dp(18),dp(23),dp(18),dp(40));scroll.addView(column);
        setContentView(scroll);
    }
    private void heading(String subtitle){
        TextView logo=text("FORGE  /  COACH",14,ACCENT,true);add(column,logo);space(column,6);
        TextView title=text("STRONGER. EVERY MONTH.",23,WHITE,true);add(column,title);space(column,6);
        add(column,text(subtitle,13,MUTED,false));space(column,20);
    }
    private void showHome(){
        showingWorkout=false;createScreen();
        heading("Mon / Wed / Fri gym  •  Tue / Sat running  •  headphone coaching");
        try{
            JSONObject plan=PlanStore.activePlan(this);
            String month=PlanStore.activeMonth(this);
            int day=LocalDate.now().getDayOfWeek().getValue();
            String[] dayNames={"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
            String todaySession=day==1?"A":day==3?"B":day==5?"C":null;
            LinearLayout today=card(column);
            add(today,text("TODAY  /  "+dayNames[day-1].toUpperCase(Locale.UK),12,ACCENT,true));space(today,6);
            String headline=todaySession!=null?"Gym "+todaySession+" · Ready to train":
                    day==2?"Easy run":day==6?"Long easy run":day==4?"Recovery and mobility":"Recovery day";
            add(today,text(headline,24,WHITE,true));space(today,6);
            add(today,text(todaySession!=null?"Timed session. Start at your own pace, with voice cues and rest periods.":
                    day==2?"35–50 minutes conversational pace, subject to your running plan.":
                    day==6?"Long easy run, initially 60–80 minutes as tolerated.":
                    "A short walk or gentle mobility is enough today.",13,MUTED,false));
            if(todaySession!=null){space(today,12);Button go=button("Start today's gym session",true);
                add(today,go);go.setOnClickListener(v->startWorkout(todaySession));}
            LinearLayout summary=card(column);
            add(summary,text(plan.optString("title",month),20,WHITE,true));space(summary,7);
            add(summary,text(plan.optString("description",""),13,MUTED,false));space(summary,14);
            add(summary,text("ACTIVE MONTH",11,ACCENT,true));space(summary,5);
            Spinner monthSpinner=new Spinner(this);
            List<String> months=PlanStore.months(this);ArrayAdapter<String> monthsAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,months);
            monthSpinner.setAdapter(monthsAdapter);monthSpinner.setSelection(Math.max(0,months.indexOf(month)));
            monthSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
                boolean initial=true;
                @Override public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long id){
                    String selected=months.get(position);
                    if(initial){initial=false;return;}
                    if(!selected.equals(PlanStore.activeMonth(MainActivity.this))){PlanStore.selectMonth(MainActivity.this,selected);
                        try{chosenWeek=PlanStore.currentWeek(PlanStore.activePlan(MainActivity.this));}catch(Exception ignored){}
                        showHome();}
                }
                @Override public void onNothingSelected(android.widget.AdapterView<?> parent){}
            });
            add(summary,monthSpinner);
            add(summary,text("TRAINING WEEK",11,ACCENT,true));space(summary,4);
            Spinner weekSpinner=new Spinner(this);
            String[] weekLabels={"Week 1 · familiarise","Week 2 · build","Week 3 · progress","Week 4 · consolidate"};
            weekSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,weekLabels));
            weekSpinner.setSelection(Math.max(0,Math.min(3,chosenWeek-1)));
            weekSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
                @Override public void onItemSelected(android.widget.AdapterView<?> p,View v,int idx,long id){chosenWeek=idx+1;}
                @Override public void onNothingSelected(android.widget.AdapterView<?> p){}
            });
            add(summary,weekSpinner);space(summary,6);
            JSONArray progression=plan.getJSONArray("progression");
            add(summary,text(progression.getJSONObject(Math.min(3,chosenWeek-1)).optString("intensity",""),12,MUTED,false));
            space(column,8);
            add(column,text("YOUR GYM SESSIONS",13,ACCENT,true));space(column,12);
            JSONArray sessions=plan.getJSONArray("sessions");
            for(int i=0;i<sessions.length();i++){
                JSONObject session=sessions.getJSONObject(i);
                String id=session.getString("id");
                LinearLayout c=card(column);
                add(c,text("SESSION  "+id+"  /  "+(i==0?"MONDAY":i==1?"WEDNESDAY":"FRIDAY"),12,ACCENT,true));space(c,5);
                add(c,text(session.optString("title",""),21,WHITE,true));space(c,4);
                add(c,text(session.optString("focus",""),13,MUTED,false));space(c,4);
                add(c,text(session.optString("description",""),12,MUTED,false));space(c,11);
                int seconds=WorkoutEngine.duration(WorkoutEngine.make(session,progression.getJSONObject(chosenWeek-1)));
                add(c,text("Timed session  ·  "+WorkoutEngine.clock(seconds)+" estimated",13,WHITE,true));space(c,12);
                LinearLayout actions=hbox();
                Button start=button("Start session",true);actions.addView(start,new LinearLayout.LayoutParams(0,dp(52),2f));
                Button details=button("Exercise list",false);LinearLayout.LayoutParams detailLp=new LinearLayout.LayoutParams(0,dp(52),1.5f);detailLp.leftMargin=dp(8);actions.addView(details,detailLp);
                add(c,actions);
                start.setOnClickListener(v->startWorkout(id));details.setOnClickListener(v->showDetails(id));
            }
            add(column,text("WEEKLY RUNS + RECOVERY",13,ACCENT,true));space(column,12);
            LinearLayout runs=card(column);
            JSONArray schedule=plan.optJSONArray("schedule");
            if(schedule!=null)for(int i=0;i<schedule.length();i++){
                JSONObject day=schedule.getJSONObject(i);
                if("gym".equals(day.optString("type")))continue;
                add(runs,text(day.optString("day","").toUpperCase()+"  ·  "+day.optString("type","").toUpperCase(),12,WHITE,true));
                add(runs,text(day.optString("note",""),12,MUTED,false));space(runs,10);
            }
            LinearLayout importCard=card(column);
            add(importCard,text("MONTHLY PROGRAMME UPDATES",14,ACCENT,true));space(importCard,8);
            add(importCard,text("Your app checks for new plans when opened, using a secure online programme feed. Workouts and history remain available offline. Your training notes are not uploaded.",13,WHITE,false));space(importCard,12);
            Button syncButton=button("Check for new monthly plan",true);add(importCard,syncButton);
            syncButton.setOnClickListener(v->{syncButton.setEnabled(false);syncButton.setText("Checking…");
                PlanSync.check(MainActivity.this,(ok,message)->{syncButton.setEnabled(true);syncButton.setText("Check for new monthly plan");
                    if(ok&&!showingWorkout){
                        try{chosenWeek=PlanStore.currentWeek(PlanStore.activePlan(MainActivity.this));}catch(Exception ignored){}
                        showHome();
                    }
                    new AlertDialog.Builder(MainActivity.this).setTitle(ok?"Programmes checked":"Update not available")
                        .setMessage(message).setPositiveButton("OK",null).show();
                });
            });
            space(importCard,9);
            Button manual=button("Import a backup plan file",false);add(importCard,manual);manual.setOnClickListener(v->chooseFile());
            space(importCard,9);
            Button source=button("Advanced: programme update source",false);add(importCard,source);
            source.setOnClickListener(v->editPlanSource());
            add(column,text("SESSION HISTORY",13,ACCENT,true));space(column,12);
            LinearLayout historyCard=card(column);JSONArray history=PlanStore.history(this);
            Button share=button("Share progress for monthly review",true);add(historyCard,share);space(historyCard,12);
            share.setOnClickListener(v->shareProgress());
            if(history.length()==0)add(historyCard,text("Completed gym sessions appear here. History is stored locally, not uploaded.",13,MUTED,false));
            else {
                for(int j=history.length()-1;j>=Math.max(0,history.length()-12);j--){
                    final int index=j;JSONObject h=history.getJSONObject(j);
                    Button log=button(h.optString("date","").substring(0,Math.min(10,h.optString("date","").length()))
                            +" · Session "+h.optString("session")+" · "+WorkoutEngine.clock(h.optInt("elapsedSeconds")),false);
                    add(historyCard,log);space(historyCard,6);log.setOnClickListener(v->editHistory(index));
                }
            }
            add(column,text("Lock-screen voice: start the session while the app is open. Keep notifications enabled and check that Android text-to-speech is installed. Test your specific phone and Bluetooth headphones before relying on it.",12,MUTED,false));
        }catch(Exception e){add(column,text("Programme error: "+e.getMessage(),14,Color.RED,false));}
    }
    private void startWorkout(String id){
        if(WorkoutService.latest!=null&&WorkoutService.latest.active){showWorkout();return;}
        Intent start=new Intent(this,WorkoutService.class).setAction(WorkoutService.START)
            .putExtra("month",PlanStore.activeMonth(this)).putExtra("session",id).putExtra("week",chosenWeek);
        try {startForegroundService(start);showWorkout();}
        catch(Exception e){toast("Android prevented the workout from starting: "+e.getMessage());}
    }
    private void command(String action){
        Intent i=new Intent(this,WorkoutService.class).setAction(action);
        startService(i);
    }
    private void showWorkout(){
        showingWorkout=true;createScreen();
        add(column,text("FORGE  /  LIVE SESSION",13,ACCENT,true));space(column,10);
        add(column,text("AUDIO COACH  •  BACKGROUND MODE",12,MUTED,true));space(column,19);
        LinearLayout main=card(column);
        phaseLabel=text("READY",13,ACCENT,true);add(main,phaseLabel);space(main,10);
        nameLabel=text("Preparing workout…",28,WHITE,true);add(main,nameLabel);space(main,7);
        blockLabel=text("",13,MUTED,false);add(main,blockLabel);space(main,10);
        timerLabel=text("00:00",79,ACCENT,true);timerLabel.setGravity(Gravity.CENTER_HORIZONTAL);add(main,timerLabel);
        cueLabel=text("",14,WHITE,false);add(main,cueLabel);space(main,13);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000);progress.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));add(main,progress);space(main,12);
        roundLabel=text("",13,MUTED,false);add(main,roundLabel);
        LinearLayout nextCard=card(column);
        add(nextCard,text("UP NEXT",12,ACCENT,true));space(nextCard,6);
        nextLabel=text("",17,WHITE,true);add(nextCard,nextLabel);space(nextCard,9);
        overallLabel=text("",12,MUTED,false);add(nextCard,overallLabel);
        pauseButton=button("Pause",true);add(column,pauseButton);pauseButton.setOnClickListener(v->command(WorkoutService.PAUSE));space(column,9);
        LinearLayout row=hbox();Button skip=button("Skip interval",false);row.addView(skip,new LinearLayout.LayoutParams(0,dp(54),1));
        Button plus=button("+15 seconds",false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(54),1);lp.leftMargin=dp(8);row.addView(plus,lp);add(column,row);
        skip.setOnClickListener(v->command(WorkoutService.SKIP));plus.setOnClickListener(v->command(WorkoutService.ADD));space(column,18);
        Button end=button("End workout",false);add(column,end);
        end.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("End workout?")
                .setMessage("Ending now will discard this incomplete session from your completed-session history.")
                .setNegativeButton("Keep going",null)
                .setPositiveButton("End session",(d,w)->{command(WorkoutService.END);showHome();}).show());
        refreshWorkout();
    }
    private void refreshWorkout(){
        if(!showingWorkout)return;
        WorkoutService.Snapshot s=WorkoutService.latest;
        if(s==null||!s.active)return;
        phaseLabel.setText(s.paused?"PAUSED · "+s.phase:s.phase);
        nameLabel.setText(s.name);timerLabel.setText(WorkoutEngine.clock(s.remaining));
        cueLabel.setText(s.cue);blockLabel.setText(s.block);
        roundLabel.setText("Interval "+s.stepIndex+" / "+s.totalSteps+(s.rounds>0?"    •    Round "+s.round+" / "+s.rounds:""));
        nextLabel.setText(s.next.isEmpty()?nextWork(s):s.next);
        overallLabel.setText("Approx. remaining: "+WorkoutEngine.clock(s.totalRemaining)+"   •   Week "+s.week);
        progress.setProgress(Math.max(0,Math.min(1000,(int)(1000f*(s.plannedTotal-s.totalRemaining)/Math.max(1,s.plannedTotal)))));
        pauseButton.setText(s.paused?"Resume session":"Pause session");
    }
    private String nextWork(WorkoutService.Snapshot s){
        if(s.phase.equals("WORK"))return "Follow the next audio instruction";
        return "Prepare for the next exercise";
    }
    private void showDetails(String id){
        try {
            JSONObject plan=PlanStore.activePlan(this);JSONObject ses=PlanStore.session(plan,id);
            JSONArray blocks=ses.getJSONArray("blocks");StringBuilder txt=new StringBuilder();
            JSONObject progression=plan.getJSONArray("progression").getJSONObject(chosenWeek-1);
            for(int b=0;b<blocks.length();b++){
                JSONObject block=blocks.getJSONObject(b);
                String kind=block.optString("kind");
                int delta="conditioning".equals(kind)?progression.optInt("conditioningRoundDelta"):
                        ("strength".equals(kind)||"accessory".equals(kind))?progression.optInt("roundDelta"):0;
                int rounds=Math.max(1,block.getInt("rounds")+delta);
                txt.append(block.getString("title")).append(" · ").append(rounds).append(" round(s)\n");
                JSONArray stations=block.getJSONArray("stations");
                for(int i=0;i<stations.length();i++){
                    JSONObject ex=stations.getJSONObject(i);
                    txt.append("   • ").append(ex.getString("name")).append(" — ").append(ex.getInt("seconds")).append("s\n");
                    if(!ex.optString("alternative").isEmpty())txt.append("      Alternative: ").append(ex.getString("alternative")).append("\n");
                }
                txt.append("Station transition: ").append(block.getInt("stationTransitionSeconds"))
                        .append("s · between rounds: ").append(block.getInt("restBetweenRoundsSeconds")).append("s\n\n");
            }
            TextView view=text(txt.toString(),14,WHITE,false);view.setPadding(dp(16),dp(10),dp(16),dp(10));
            ScrollView sc=new ScrollView(this);sc.setBackgroundColor(BG);sc.addView(view);
            new AlertDialog.Builder(this).setTitle(ses.optString("title")+" · Week "+chosenWeek)
                    .setView(sc).setPositiveButton("Close",null).show();
        } catch(Exception e){toast("Cannot display exercise list: "+e.getMessage());}
    }
    private void editPlanSource(){
        EditText field=new EditText(this);field.setText(PlanSync.manifestUrl(this));
        field.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);
        field.setSingleLine(false);field.setPadding(dp(18),dp(16),dp(18),dp(16));
        new AlertDialog.Builder(this).setTitle("Programme source")
            .setMessage("Only change this if the Forge Coach update address changes. Monthly plans should download automatically after the programme repository is published.")
            .setView(field).setNegativeButton("Cancel",null)
            .setPositiveButton("Save",(dialog,which)->{
                try{PlanSync.setManifestUrl(this,field.getText().toString());toast("Programme source saved");}
                catch(Exception e){new AlertDialog.Builder(this).setMessage(e.getMessage()).setPositiveButton("OK",null).show();}
            }).show();
    }
    private void chooseFile(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/plain","application/octet-stream"});
        startActivityForResult(i,FILE_REQUEST);
    }
    @Override protected void onActivityResult(int req,int code,Intent data){
        super.onActivityResult(req,code,data);
        if(req!=FILE_REQUEST||code!=RESULT_OK||data==null||data.getData()==null)return;
        if(WorkoutService.latest!=null&&WorkoutService.latest.active){toast("End your current workout before importing a new plan.");return;}
        Uri uri=data.getData();
        try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){
            if(in==null)throw new Exception("Cannot open file");
            byte[] buf=new byte[8192];int n,total=0;
            while((n=in.read(buf))!=-1){total+=n;if(total>500_000)throw new Exception("Plan must be under 500KB");out.write(buf,0,n);}
            String raw=out.toString(StandardCharsets.UTF_8.name());
            String month=PlanStore.validate(raw);PlanStore.importPlan(this,raw);
            chosenWeek=PlanStore.currentWeek(PlanStore.activePlan(this));
            showHome();toast("Imported "+month+" plan. Previous plans and history retained.");
        }catch(Exception e){new AlertDialog.Builder(this).setTitle("Import unsuccessful")
                .setMessage("Plan was not applied. "+e.getMessage()).setPositiveButton("OK",null).show();}
    }
    private void shareProgress(){
        try{
            JSONObject export=new JSONObject();export.put("exportType","Forge Coach Training Review");
            export.put("exportedAt",java.time.LocalDateTime.now().toString());
            export.put("history",PlanStore.history(this));
            export.put("activeMonth",PlanStore.activeMonth(this));
            Intent share=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT,"Forge Coach training history").putExtra(Intent.EXTRA_TEXT,export.toString(2));
            startActivity(Intent.createChooser(share,"Share training log"));
        }catch(Exception e){toast("Could not export history: "+e.getMessage());}
    }
    private void editHistory(int idx){
        JSONArray h=PlanStore.history(this);
        if(idx<0||idx>=h.length())return;
        JSONObject entry=h.optJSONObject(idx);
        EditText input=new EditText(this);input.setText(entry.optString("notes",""));
        input.setHint("Weights used, effort 1–10, form notes, substitutions");input.setMinLines(3);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        new AlertDialog.Builder(this).setTitle("Session "+entry.optString("session")+" · training notes")
                .setMessage("Log weight selections and effort. These notes help decide how to progress next month.")
                .setView(input).setNegativeButton("Cancel",null)
                .setPositiveButton("Save notes",(d,w)->{PlanStore.updateHistoryNotes(this,idx,input.getText().toString());showHome();})
                .show();
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override public void onBackPressed(){
        if(WorkoutService.latest!=null&&WorkoutService.latest.active){
            new AlertDialog.Builder(this).setTitle("Workout still running")
                .setMessage("You can lock your screen or return to the home screen. Voice guidance continues.")
                .setPositiveButton("Keep workout running",(d,w)->moveTaskToBack(true))
                .setNegativeButton("Stay here",null).show();
        }else super.onBackPressed();
    }
}
