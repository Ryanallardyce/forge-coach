package uk.co.forgecoach;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class PlanStore {
    private static final String PREFS = "forge_coach_data_v2";
    private PlanStore() {}

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    static void initialise(Context c) throws Exception {
        if (prefs(c).getInt("bundled_plan_revision",0) >= 3) return;
        try (InputStream in = c.getAssets().open("default-plan.json")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];int n;
            while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
            String raw = new String(out.toByteArray(), StandardCharsets.UTF_8);
            String month = validate(raw);
            upsertPlan(c,raw,false);
            // An earlier installation may contain the same month with an outdated start date.
            prefs(c).edit().putInt("bundled_plan_revision",3).apply();
            selectNewestStartedPlan(c);
        }
    }

    static String validate(String raw) throws JSONException {
        if (raw == null || raw.length() > 500_000) throw new JSONException("File is too large (500 KB maximum).");
        JSONObject plan = new JSONObject(raw);
        if (plan.optInt("schemaVersion", 0) != 2) throw new JSONException("Expected Forge Coach plan schemaVersion 2.");
        String month = plan.getString("month");
        if (!month.matches("20[0-9]{2}-(0[1-9]|1[0-2])")) throw new JSONException("month must be YYYY-MM.");
        LocalDate start = LocalDate.parse(plan.getString("startDate"));
        if (!start.toString().startsWith(month)) throw new JSONException("startDate must be in selected month.");
        JSONArray sessions = plan.getJSONArray("sessions");
        if (sessions.length() != 3) throw new JSONException("Provide exactly three sessions A, B and C.");
        for (int i=0; i<3; i++) {
            JSONObject session = sessions.getJSONObject(i);
            String expected = new String[]{"A", "B", "C"}[i];
            if (!expected.equals(session.getString("id"))) throw new JSONException("Sessions must be A, B and C in order.");
            if (session.optString("title", "").trim().isEmpty()) throw new JSONException("Session title is required.");
            JSONArray blocks = session.getJSONArray("blocks");
            if (blocks.length() < 1 || blocks.length() > 12) throw new JSONException("Each session needs 1–12 blocks.");
            int estimated = 0;
            for (int j=0;j<blocks.length();j++) {
                JSONObject b = blocks.getJSONObject(j);
                checked(b,"rounds",1,8);
                checked(b,"stationTransitionSeconds",0,300);
                checked(b,"restBetweenRoundsSeconds",0,300);
                checked(b,"blockTransitionSeconds",0,300);
                String kind = b.getString("kind");
                if (!kind.matches("warmup|strength|accessory|conditioning|mobility")) throw new JSONException("Unsupported block kind: " + kind);
                JSONArray stations = b.getJSONArray("stations");
                if (stations.length() < 1 || stations.length() > 15) throw new JSONException("Each block needs 1–15 stations.");
                int roundSec = 0;
                for(int k=0;k<stations.length();k++) {
                    JSONObject station=stations.getJSONObject(k);
                    if (station.optString("name", "").trim().isEmpty()) throw new JSONException("Station name is required.");
                    roundSec += checked(station,"seconds",10,600);
                }
                estimated+=b.getInt("rounds")*(roundSec+stations.length()*b.getInt("stationTransitionSeconds")+b.getInt("restBetweenRoundsSeconds"))+b.getInt("blockTransitionSeconds");
            }
            if (estimated > 2*60*60) throw new JSONException("Session is longer than two hours.");
        }
        JSONArray progression=plan.getJSONArray("progression");
        if (progression.length() != 4) throw new JSONException("Provide four weekly progression entries.");
        for(int i=0;i<4;i++) {
            JSONObject w=progression.getJSONObject(i);
            if(w.getInt("week")!=i+1) throw new JSONException("Progression weeks must be 1–4.");
            if(Math.abs(w.optInt("roundDelta"))>2 || Math.abs(w.optInt("conditioningRoundDelta"))>2) throw new JSONException("Round changes may not exceed two.");
        }
        return month;
    }

    private static int checked(JSONObject o, String key, int lo, int hi) throws JSONException {
        int val=o.getInt(key);
        if(val<lo || val>hi) throw new JSONException(key + " must be between " + lo + " and " + hi + ".");
        return val;
    }

    static void importPlan(Context c, String raw) throws JSONException { upsertPlan(c,raw,true); }

    static void upsertPlan(Context c, String raw, boolean select) throws JSONException {
        String month=validate(raw);
        SharedPreferences p=prefs(c);
        List<String> months=months(c);
        if(!months.contains(month))months.add(month);
        Collections.sort(months);
        SharedPreferences.Editor edit=p.edit().putString("months",String.join(",",months))
                .putString("plan_"+month,raw);
        if(select || !p.contains("active_month"))edit.putString("active_month",month);
        edit.apply();
    }
    static void selectNewestStartedPlan(Context c) {
        String best=null;LocalDate today=LocalDate.now();LocalDate latest=null;
        for(String m:months(c))try{
            LocalDate start=LocalDate.parse(getPlan(c,m).getString("startDate"));
            if(!start.isAfter(today) && (latest==null || start.isAfter(latest))){latest=start;best=m;}
        }catch(Exception ignored){}
        if(best!=null)selectMonth(c,best);
    }

    static List<String> months(Context c) {
        String stored=prefs(c).getString("months","");
        List<String> months=new ArrayList<>();
        if(!stored.isEmpty()) for(String m:stored.split(",")) if(m.matches("20[0-9]{2}-[0-9]{2}")) months.add(m);
        return months;
    }

    static String activeMonth(Context c) { return prefs(c).getString("active_month","2026-11"); }
    static void selectMonth(Context c,String month) {
        if(months(c).contains(month)) prefs(c).edit().putString("active_month",month).apply();
    }
    static JSONObject activePlan(Context c) throws JSONException { return getPlan(c,activeMonth(c)); }
    static JSONObject getPlan(Context c,String month) throws JSONException {
        String raw=prefs(c).getString("plan_"+month,null);
        if(raw==null) throw new JSONException("Monthly plan not installed: "+month);
        return new JSONObject(raw);
    }
    static int currentWeek(JSONObject plan) {
        try {
            long days=ChronoUnit.DAYS.between(LocalDate.parse(plan.getString("startDate")), LocalDate.now());
            return Math.max(1,Math.min(4,(int)Math.floorDiv(days,7)+1));
        } catch(Exception e) {return 1;}
    }
    static JSONObject session(JSONObject plan,String id) throws JSONException {
        JSONArray sessions=plan.getJSONArray("sessions");
        for(int i=0;i<sessions.length();i++) if(id.equals(sessions.getJSONObject(i).optString("id"))) return sessions.getJSONObject(i);
        throw new JSONException("Unknown session: "+id);
    }
    static void appendHistory(Context c,String month,String session,int week,int actualSeconds,String notes) {
        try {
            JSONArray h=new JSONArray(prefs(c).getString("history","[]"));
            JSONObject entry=new JSONObject();
            entry.put("date",java.time.LocalDateTime.now().toString());entry.put("month",month);
            entry.put("session",session);entry.put("week",week);entry.put("elapsedSeconds",actualSeconds);
            entry.put("notes",notes == null ? "" : notes.substring(0,Math.min(notes.length(),500)));
            h.put(entry);
            prefs(c).edit().putString("history",h.toString()).apply();
        } catch(Exception ignored) {}
    }
    static void updateHistoryNotes(Context c, int index, String notes) {
        try {
            JSONArray h=history(c);
            if(index<0||index>=h.length())return;
            h.getJSONObject(index).put("notes",notes==null?"":notes.substring(0,Math.min(500,notes.length())));
            prefs(c).edit().putString("history",h.toString()).apply();
        } catch(Exception ignored) {}
    }
    static JSONArray history(Context c) {
        try {return new JSONArray(prefs(c).getString("history","[]"));}
        catch(JSONException e){return new JSONArray();}
    }
}
