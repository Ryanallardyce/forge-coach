package uk.co.forgecoach;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.*;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import org.json.JSONObject;
import java.util.List;
import java.util.Locale;

public class WorkoutService extends Service {
    public static final String START="uk.co.forgecoach.START",PAUSE="uk.co.forgecoach.PAUSE",
            SKIP="uk.co.forgecoach.SKIP", ADD="uk.co.forgecoach.ADD",END="uk.co.forgecoach.END",
            QUERY="uk.co.forgecoach.QUERY", UPDATE="uk.co.forgecoach.UPDATE";
    private static final String CHANNEL="forge_workout_v2";
    private static final int NOTIFICATION_ID=106;
    public static volatile Snapshot latest;
    public static final class Snapshot {
        public boolean active,paused;
        public String phase="",name="",cue="",block="",next="",month="",session="";
        public int remaining,totalRemaining,plannedTotal,week,stepIndex,totalSteps,round,rounds;
    }
    private final Handler handler=new Handler(Looper.getMainLooper());
    private List<WorkoutEngine.Step> steps;
    private int index,lastSpokenCountdown=-1,plannedSeconds,lastPublishedSecond=-1;
    private long endAt, remainingMs, startedAt, pauseStartedAt, pausedTotalMs;
    private String month,session,notes="";
    private int week;
    private boolean paused=false,sideSaid=false,active=false;
    private PowerManager.WakeLock lock;
    private TextToSpeech speaker;
    private boolean speechReady=false;
    private String pendingSpeech;
    private AudioManager audio;
    private AudioFocusRequest audioFocus;
    private final Runnable ticker=new Runnable(){ public void run(){ tick(); if(active)handler.postDelayed(this,250); }};

    @Override public void onCreate(){super.onCreate();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(
            new NotificationChannel(CHANNEL,"Active workout",NotificationManager.IMPORTANCE_LOW));
        speaker=new TextToSpeech(getApplicationContext(), status->{
            speechReady=status==TextToSpeech.SUCCESS;
            if(speechReady){speaker.setLanguage(Locale.UK);speaker.setSpeechRate(0.98f);
                speaker.setOnUtteranceProgressListener(new UtteranceProgressListener(){
                    @Override public void onStart(String id) {}
                    @Override public void onDone(String id) {handler.post(()->releaseAudioFocus());}
                    @Override public void onError(String id) {handler.post(()->releaseAudioFocus());}
                });
                if(pendingSpeech!=null){String text=pendingSpeech;pendingSpeech=null;say(text);}
            }
        });
        audio=(AudioManager)getSystemService(AUDIO_SERVICE);
    }
    @Override public int onStartCommand(Intent i,int flags,int startId){
        if(i==null){if(!active)stopSelf();return START_NOT_STICKY;}
        String action=i.getAction();
        if(START.equals(action)){
            if(!active) begin(i.getStringExtra("month"),i.getStringExtra("session"),i.getIntExtra("week",1));
        } else if(PAUSE.equals(action))togglePause();
        else if(SKIP.equals(action))skip();
        else if(ADD.equals(action))addTime();
        else if(END.equals(action))finish(false);
        else if(QUERY.equals(action))publish(false);
        return active?START_STICKY:START_NOT_STICKY;
    }
    private void begin(String m,String s,int w){
        try{
            JSONObject plan=PlanStore.getPlan(this,m);
            JSONObject sessionObj=PlanStore.session(plan,s);
            JSONObject progression=plan.getJSONArray("progression").getJSONObject(Math.max(0,Math.min(3,w-1)));
            steps=WorkoutEngine.make(sessionObj,progression);
            month=m;session=s;week=w; plannedSeconds=WorkoutEngine.duration(steps);
            index=0;paused=false;active=true;startedAt=SystemClock.elapsedRealtime();pausedTotalMs=0;pauseStartedAt=0;
            PowerManager power=(PowerManager)getSystemService(POWER_SERVICE);
            lock=power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"ForgeCoach:ActiveWorkout");
            lock.acquire();
            if(Build.VERSION.SDK_INT>=29)startForeground(NOTIFICATION_ID,makeNotification(),ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(NOTIFICATION_ID,makeNotification());
            enter(0,SystemClock.elapsedRealtime());
            handler.removeCallbacks(ticker);handler.post(ticker);
        }catch(Exception e){
            active=false;
            stopSelf();
            android.util.Log.e("ForgeCoach","Could not start session",e);
            Intent err=new Intent(UPDATE).setPackage(getPackageName()).putExtra("error","Could not load workout: "+e.getMessage());sendBroadcast(err);
        }
    }
    private void enter(int newIndex,long baseTime){
        index=newIndex;lastSpokenCountdown=-1;lastPublishedSecond=-1;sideSaid=false;
        if(index>=steps.size()){finish(true);return;}
        WorkoutEngine.Step step=steps.get(index);
        endAt=baseTime+(long)step.seconds*1000L;remainingMs=(long)step.seconds*1000L;
        if(step.phase.equals("WORK")){
            String msg="Start "+step.name+". "+step.seconds+" seconds. "+step.cue;
            if(step.rounds>1) msg="Round "+step.round+" of "+step.rounds+". "+msg;
            say(msg);
        } else if(step.phase.equals("REST")) say("Recovery. "+step.seconds+" seconds. Next: "+step.next);
        else if(step.phase.equals("CHANGE")) say("Change station. "+step.seconds+" seconds. Next: "+step.next);
        else if(step.phase.equals("SETUP")) say("New block. "+step.cue+". "+step.seconds+" seconds to prepare. First: "+step.next);
        publish(false);updateNotification();
    }
    private void tick(){
        if(!active || paused)return;
        long now=SystemClock.elapsedRealtime();
        if(now>=endAt){
            // End timestamps, rather than callback delays, are the source of truth.
            int guard=0;
            while(active && now>=endAt && guard++<100){long due=endAt;enter(index+1,due);}
            if(!active)return;
        }
        long millis=Math.max(0,endAt-now);
        int seconds=(int)Math.ceil(millis/1000.0);
        WorkoutEngine.Step step=steps.get(index);
        if(step.switchSides && step.phase.equals("WORK") && !sideSaid && millis <=step.seconds*500L){
            sideSaid=true;say("Switch sides");
        }
        if(seconds<=3 && seconds>0 && lastSpokenCountdown!=seconds && step.seconds>=10){
            lastSpokenCountdown=seconds;
            // Keep countdown brief; avoid interrupting a queued exercise title.
            if(seconds==3)say("Three");else if(seconds==2)say("Two");else say("One");
        }
        if(seconds!=lastPublishedSecond){
            lastPublishedSecond=seconds;publish(false);
            if(seconds%5==0)updateNotification();
        }
    }
    private void togglePause(){
        if(!active)return;
        if(paused){
            paused=false;pausedTotalMs+=SystemClock.elapsedRealtime()-pauseStartedAt;endAt=SystemClock.elapsedRealtime()+remainingMs;say("Resume "+steps.get(index).name);
        } else {
            paused=true;pauseStartedAt=SystemClock.elapsedRealtime();remainingMs=Math.max(0,endAt-pauseStartedAt);
            if(speaker!=null)speaker.stop();releaseAudioFocus();
        }
        publish(false);updateNotification();
    }
    private void skip(){
        if(!active)return;
        if(paused)pausedTotalMs+=SystemClock.elapsedRealtime()-pauseStartedAt;
        paused=false;enter(index+1,SystemClock.elapsedRealtime());
    }
    private void addTime(){
        if(!active)return;
        if(paused)remainingMs+=15000;else endAt+=15000;
        say("Added fifteen seconds");publish(false);updateNotification();
    }
    private void finish(boolean completed){
        if(!active)return;
        long now=SystemClock.elapsedRealtime();
        int elapsed=(int)Math.max(0,(now-startedAt-pausedTotalMs-(paused?now-pauseStartedAt:0))/1000L);
        if(completed)PlanStore.appendHistory(this,month,session,week,elapsed,notes);
        active=false;
        Snapshot ended=new Snapshot();ended.active=false;latest=ended;
        Intent update=new Intent(UPDATE).setPackage(getPackageName());update.putExtra("completed",completed);sendBroadcast(update);
        if(completed)say("Workout complete. Excellent work. Take time to recover.");
        handler.removeCallbacks(ticker);
        if(lock!=null && lock.isHeld())lock.release();
        stopForeground(STOP_FOREGROUND_REMOVE);
        if(completed)handler.postDelayed(this::stopSelf,2500);else stopSelf();
    }
    private void say(String words){
        if(words==null||words.trim().isEmpty())return;
        if(!speechReady){pendingSpeech=words;return;}
        if(audioFocus==null && Build.VERSION.SDK_INT>=26){
            audioFocus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()).build();
        }
        if(audioFocus!=null)audio.requestAudioFocus(audioFocus);
        speaker.speak(words,TextToSpeech.QUEUE_FLUSH,null,"forge_"+SystemClock.elapsedRealtime());
    }
    private void releaseAudioFocus(){if(audioFocus!=null && audio!=null)audio.abandonAudioFocusRequest(audioFocus);}
    private void publish(boolean finished){
        if(!active||steps==null)return;
        WorkoutEngine.Step step=steps.get(index);
        Snapshot s=new Snapshot();s.active=true;s.paused=paused;s.phase=step.phase;s.name=step.name;
        s.cue=step.cue;s.block=step.block;s.next=step.next;s.month=month;s.session=session;s.week=week;
        if(s.next.isEmpty()){
            for(int j=index+1;j<steps.size();j++) if("WORK".equals(steps.get(j).phase)){s.next=steps.get(j).name;break;}
        }
        s.round=step.round;s.rounds=step.rounds;s.stepIndex=index+1;s.totalSteps=steps.size();s.plannedTotal=plannedSeconds;
        long rem=paused?remainingMs:Math.max(0,endAt-SystemClock.elapsedRealtime());
        s.remaining=(int)Math.ceil(rem/1000.0);
        int rest=s.remaining;
        for(int j=index+1;j<steps.size();j++)rest+=steps.get(j).seconds;
        s.totalRemaining=rest;latest=s;
        // Explicit app-local broadcast; no data leaves the device.
        Intent update=new Intent(UPDATE).setPackage(getPackageName());sendBroadcast(update);
    }
    private PendingIntent serviceAction(String name,int id){
        Intent i=new Intent(this,WorkoutService.class).setAction(name);
        return PendingIntent.getService(this,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private Notification makeNotification(){
        Snapshot s=latest;
        boolean isPaused=s!=null&&s.paused;
        String title="Forge Coach · "+(session==null?"Workout":session);
        String line=s!=null&&s.active?(isPaused?"Paused · ":"")+s.name+" · "+WorkoutEngine.clock(s.remaining):"Starting workout";
        Intent launch=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content=PendingIntent.getActivity(this,20,launch,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,CHANNEL)
                .setSmallIcon(uk.co.forgecoach.R.drawable.forge_icon)
                .setContentTitle(title).setContentText(line).setContentIntent(content)
                .setOngoing(true).setOnlyAlertOnce(true).setShowWhen(false)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(new Notification.Action.Builder(null,isPaused?"Resume":"Pause",serviceAction(PAUSE,10)).build())
                .addAction(new Notification.Action.Builder(null,"Skip",serviceAction(SKIP,11)).build())
                .build();
    }
    private void updateNotification(){
        if(active)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID,makeNotification());
    }
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public void onDestroy(){
        active=false;handler.removeCallbacks(ticker);
        if(lock!=null&&lock.isHeld())lock.release();
        if(speaker!=null){speaker.stop();speaker.shutdown();}releaseAudioFocus();
        latest=null;
        super.onDestroy();
    }
}
