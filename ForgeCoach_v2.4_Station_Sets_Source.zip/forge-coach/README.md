# Forge Coach v2.4 — 23 November restart + station-by-station gym coach

## Restarted programme — 23 November to 20 December 2026

The November plan has been restarted after around six weeks off due to illness. Week 1 (23–29 Nov) deliberately uses one easy set per resistance exercise (RPE 5–6), with Wednesday/Friday sessions optional depending on recovery. Running is optional and scaled back to walking/run-walk. Week 2 uses two sets, Week 3 can rise to three if recovery permits, and Week 4 consolidates. The plan is included in `app/src/main/assets/default-plan.json` and `plans/2026-11.json`; the public feed hash has been regenerated. Do not train with fever, chest symptoms, abnormal breathlessness or severe fatigue.

## What's new in v2.4

- **Straight sets at each gym station.** Strength and accessory exercises now complete all prescribed sets before the next machine, rather than alternating in a circuit between gym rooms. Rest between sets is usually 100 seconds (strength) or 75 seconds (accessory), with a distinct equipment change of at least 75 seconds. Existing installed plans automatically use the new engine, so a November training-plan re-import is not necessary.
- **Repetition targets rather than rushing the timer.** Strength exercises show 8–12 reps or movement-specific targets. The set timer remains available for hands-free automatic progression; press **Finish this set** when you reach the target before the timer ends. Prioritise technique, not finishing the countdown.
- **Refreshed workout interface** in dark charcoal and orange, with larger active animation, target reps and sets, a circular remaining-time indicator, next-station preview and pause/skip/extra-time controls.
- **More legible offline animations.** Thirty-eight movement-specific, labelled GIFs are packaged locally. They illustrate movement and equipment category, but are simplified schematics rather than photorealistic technique demonstrations or exact gym equipment models. Open **Full exercise guide** for machine selection, form cues, and alternatives.
- **Last used weights.** During a set, tap **Record / change weight** to store the load per exercise locally on the phone. Existing session history and its export/restore flow remain intact.
- **Same background audio coach**, including countdowns at 10 and 5 seconds plus 3-2-1, Bluetooth headphones, Spotify ducking and foreground lock-screen operation.

### Session duration

Timings vary by progression week. Longer sessions are a trade-off for meaningful inter-set recovery and walking between equipment. After the restart, estimated Week 1 durations are about 28–32 minutes, Week 2 about 45–51 minutes, and Week 3 about 60–70 minutes (before voluntary extra rest or machine queues). Week 1 and Week 4 are shorter.

## Building the app

The ChatGPT-provided ZIP is **Android source code**, not an APK. The GitHub repository has an Actions workflow called `Build Forge Coach v2.4 APK` that runs after the root-level `ForgeCoach_v2.4_Station_Sets_Source.zip` is uploaded to the `main` branch. It unpacks this project, runs offline checks and Gradle `assembleRelease`, then attaches a ZIP containing the signed `app-release.apk` under the build's Artifacts (after the signing secret has been configured).

Do not upload workout histories, passwords or personally identifying information to the public repository. User session records and loads are only saved on the phone, not uploaded.

### Installing over v2.3

**v2.3 was debug-signed using an unavailable old certificate.** Android will reject an in-place update to the new stable-signed v2.4 APK. Before any attempt to uninstall, export a copy of your training history using **Share progress for monthly review**; retain that text securely. If an in-place update fails with a signature mismatch, a fresh install is necessary and **Restore saved history from clipboard** can recover exported session records. v2.4 exports include saved exercise weights, and the restore tool accepts older v2.3 exports without weights.

Avoid uninstalling your working application until the new APK has been built and the history export has been verified. In a subsequent release, configure a persistent signing certificate stored securely as a GitHub Actions secret to support straightforward updates.

## Technical notes

- App package `uk.co.forgecoach`, Android SDK 26+, v2.4 `versionCode=7`.
- Source in `app/src/main/java/uk/co/forgecoach`.
- Bundled monthly plan in `app/src/main/assets/default-plan.json`. Monthly plan feed in `plans/index.json` points to published November plan only. December and January remain drafts and should be revised against training results before publication.
- The station-first transformation happens in `WorkoutEngine.make`, so existing stored schemaVersion 2 plans continue to work without overwriting their contents.
- Workout history in the unchanged `forge_coach_data_v2` app preferences; preserved only on a compatible in-place update.

### Validation

```bash
python3 scripts/validate_plan.py app/src/main/assets/default-plan.json
python3 scripts/test_feed.py
python3 scripts/validate_visuals.py
# Android SDK/Gradle are required to compile the APK.
gradle --no-daemon assembleDebug
```

## Real device test plan

1. Start a resistance workout; confirm **Leg press Set 1**, **rest at same machine**, **Set 2**, and **Set 3** occur consecutively before any change to **Lat pulldown**.
2. Test manual **Finish this set**, pause/resume, add 15 seconds and skip rest.
3. Verify the current GIF loads automatically and equipment labels correspond to the named exercise.
4. Pair Bluetooth headphones, play Spotify, lock the screen for several minutes, and confirm reliable voice announcements and countdowns.
5. Check the app's battery usage and Android notification permission if phone vendors suspend background activity.
6. Record a weight, close/reopen the app, and confirm it persists; export and inspect session history.

## Persistent release signing (v2.4 onward)

The source ZIP contains **only an encrypted** PKCS#12 signing key at `signing/forge-coach-release.p12.enc`. It does **not** contain the password or the unencrypted private key. A separate **private** text file named `ForgeCoach_v2.4_PRIVATE_SIGNING_PASSWORD.txt` contains the high-entropy passphrase and must never be uploaded to the public repository or pasted in an issue.

Before triggering the v2.4 GitHub build, open the GitHub repo's **Settings → Secrets and variables → Actions → New repository secret** and create:

- **Name:** `FORGE_COACH_SIGNING_PASSPHRASE`
- **Value:** the secret value from the private password file (the one long line only).

The `.github/workflows/build-v24.yml` workflow in the repository decrypts the key only inside the temporary GitHub Actions runner, compiles a **release-signed APK**, uploads it as a build artifact, and deletes the unencrypted key at the end of the build. The private key never appears in public repository content.

This creates a stable release identity for v2.4 and later. **It does not make the v2.3 debug APK updateable in place**: Android cannot accept a different certificate on an installed app. Backup/restore history and make a one-time clean install for v2.4; later releases signed by this same key can update v2.4 in place as long as `applicationId` remains `uk.co.forgecoach` and `versionCode` increases. Keep the encrypted keystore and the private password safe; loss of either prevents signing compatible updates.
