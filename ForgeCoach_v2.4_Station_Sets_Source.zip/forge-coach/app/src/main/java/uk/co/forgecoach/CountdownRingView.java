package uk.co.forgecoach;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Draws a simple countdown ring without affecting the foreground timer service. */
public final class CountdownRingView extends View {
    private final Paint track=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint active=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arc=new RectF();
    private float fraction=1f;

    public CountdownRingView(Context context){
        super(context);
        track.setColor(0xff344351); track.setStyle(Paint.Style.STROKE);
        track.setStrokeCap(Paint.Cap.ROUND);
        active.setColor(0xffff8a00); active.setStyle(Paint.Style.STROKE);
        active.setStrokeCap(Paint.Cap.ROUND);
    }
    public void setFraction(float remaining){
        fraction=Math.max(0f,Math.min(1f,remaining));invalidate();
    }
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        float density=getResources().getDisplayMetrics().density;
        float r=9*density,margin=r+5*density;
        track.setStrokeWidth(r);active.setStrokeWidth(r);
        float left=margin,top=margin,right=getWidth()-margin,bottom=getHeight()-margin;
        arc.set(left,top,right,bottom);
        c.drawArc(arc,-90,360,false,track);
        c.drawArc(arc,-90,360*fraction,false,active);
    }
}
