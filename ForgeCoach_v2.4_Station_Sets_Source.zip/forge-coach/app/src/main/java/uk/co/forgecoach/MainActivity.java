package uk.co.forgecoach;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(11,18,26), CARD=Color.rgb(27,38,50),
            ACCENT=Color.rgb(255,138,0), WHITE=Color.rgb(245,248,250), MUTED=Color.rgb(169,181,193), BORDER=Color.rgb(55,69,81);
    private static final int FILE_REQUEST=101;
    private LinearLayout column,bottomControls;
    private boolean showingWorkout=false;
    private TextView phaseLabel,nameLabel,timerLabel,cueLabel,nextLabel,overallLabel,roundLabel,blockLabel,autoDemoLabel,
            repsLabel,weightLabel,setsLabel,stationLabel,previewEquipmentLabel;
    private CountdownRingView ring;
    private Button skipButton;
    private String activeGuideExercise="";
    private GifView liveGif;
    private String displayedLiveGifAsset = "";
    private ProgressBar progress;
    private Button pauseButton;
    private int chosenWeek=1;
    private final BroadcastReceiver receiver=new BroadcastReceiver(){
        @Override public void onReceive(Context c,Intent intent){
            if(intent.hasExtra("error")) {toast(intent.getStringExtra("error"));showHome();return;}
            if(intent.getBooleanExtra("completed",false)) {
                showHome();new AlertDialog.Builder(MainActivity.this).setTitle("Workout complete")
                        .setMessage("Session saved locally. Record the weight you used, effort (RPE), and any exercise changes to inform next month's plan.")
                        .setPositiveButton("Add notes",(dialog,which)->editHistory(PlanStore.history(MainActivity.this).length()-1))
                        .setNegativeButton("Later",null).show();return;
            }
            if(WorkoutService.latest==null||!WorkoutService.latest.active){if(showingWorkout)showHome();return;}
            if(!showingWorkout)showWorkout();else refreshWorkout();
        }
    };
    @Override public void onCreate(Bundle b){super.onCreate(b);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        try{PlanStore.initialise(this);chosenWeek=PlanStore.currentWeek(PlanStore.activePlan(this));}
        catch(Exception e){new AlertDialog.Builder(this).setMessage("Unable to load included plan: "+e.getMessage()).show();}
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},200);
        }
        if(WorkoutService.latest!=null&&WorkoutService.latest.active)showWorkout();else showHome();
        // Automatic once-daily check when online. A failed check never blocks offline workouts.
        if(PlanSync.isDue(this))PlanSync.check(this,(ok,message)->{
            if(ok && !showingWorkout && !isFinishing()){
                try{chosenWeek=PlanStore.currentWeek(PlanStore.activePlan(this));}catch(Exception ignored){}
                showHome();
            }
        });
    }
    @Override protected void onStart(){super.onStart();
        IntentFilter f=new IntentFilter(WorkoutService.UPDATE);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver,f);
        if(WorkoutService.latest!=null && WorkoutService.latest.active){if(!showingWorkout)showWorkout();else refreshWorkout();}
    }
    @Override protected void onStop(){try{unregisterReceiver(receiver);}catch(Exception ignored){}super.onStop();}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);if(WorkoutService.latest!=null&&WorkoutService.latest.active)showWorkout();}

    private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+0.5f);}
    private GradientDrawable surface(int color,int stroke,int radius){
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));
        if(stroke!=0)g.setStroke(dp(1),stroke);return g;
    }
    private TextView text(String str,int size,int color,boolean bold){
        TextView v=new TextView(this);v.setText(str);v.setTextSize(size);v.setTextColor(color);
        v.setFontFeatureSettings("tnum");if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        v.setGravity(Gravity.START);return v;
    }
    private LinearLayout vbox(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout hbox(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void space(LinearLayout l,int height){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(height)));}
    private void add(LinearLayout parent,View v){parent.addView(v,new LinearLayout.LayoutParams(-1,-2));}
    private LinearLayout card(LinearLayout parent){
        LinearLayout c=vbox();c.setPadding(dp(17),dp(16),dp(17),dp(16));c.setBackground(surface(CARD,BORDER,16));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(14);parent.addView(c,lp);return c;
    }
    private Button button(String label,boolean primary){
        Button b=new Button(this);b.setText(label);b.setTextSize(15);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setTextColor(primary?BG:WHITE);b.setBackground(surface(primary?ACCENT:Color.rgb(46,59,72),0,12));
        b.setMinHeight(dp(52));b.setPadding(dp(12),dp(10),dp(12),dp(10));return b;
    }
    private void createScreen(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        column=vbox();column.setPadding(dp(18),dp(23),dp(18),dp(40));scroll.addView(column);
        setContentView(scroll);
    }
    /** Live workout controls remain visible while the detailed training screen scrolls. */
    private void createWorkoutScreen(){
        LinearLayout root=vbox();root.setBackgroundColor(BG);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);
        column=vbox();column.setPadding(dp(18),dp(18),dp(18),dp(12));scroll.addView(column);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));
        bottomControls=vbox();
        bottomControls.setPadding(dp(16),dp(9),dp(16),dp(10));
        bottomControls.setBackground(surface(CARD,BORDER,14));
        root.addView(bottomControls,new LinearLayout.LayoutParams(-1,-2));
        setContentView(root);
    }

    private void heading(String subtitle){
        TextView logo=text("▣  FORGE  /  COACH",15,ACCENT,true);add(column,logo);space(column,5);
        TextView title=text("STRONGER. EVERY MONTH.",23,WHITE,true);add(column,title);space(column,7);
        add(column,text(subtitle,13,MUTED,false));space(column,18);
    }
    private void showHome(){
        showingWorkout=false;createScreen();
        heading("Mon / Wed / Fri gym  •  Tue / Sat running  •  headphone coaching");
        try{
            JSONObject plan=PlanStore.activePlan(this);
            String month=PlanStore.activeMonth(this);
            int day=LocalDate.now().getDayOfWeek().getValue();
            String[] dayNames={"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
            String todaySession=day==1?"A":day==3?"B":day==5?"C":null;
            LinearLayout today=card(column);
            add(today,text("TODAY  /  "+dayNames[day-1].toUpperCase(Locale.UK),12,ACCENT,true));space(today,6);
            String headline=todaySession!=null?"Gym "+todaySession+" · Ready to train":
                    day==2?"Easy run":day==6?"Long easy run":day==4?"Recovery and mobility":"Recovery day";
            add(today,text(headline,24,WHITE,true));space(today,6);
            add(today,text(todaySession!=null?"Finish every set at one machine before moving on. Voice coaching works with Spotify and screen lock.":
                    day==2?"Week 1: choose a 15–25 min easy walk or run/walk only if recovered. No speed work.":
                    day==6?"Week 1: optional 25–40 min easy walk or run/walk, not a long run.":
                    "Prioritise recovery and mobility; no pressure to make up missed sessions.",13,MUTED,false));
            if(todaySession!=null){space(today,12);Button go=button("Start today's gym session",true);
                add(today,go);go.setOnClickListener(v->startWorkout(todaySession));}
            LinearLayout summary=card(column);
            add(summary,text(plan.optString("title",month),20,WHITE,true));space(summary,7);
            add(summary,text(plan.optString("description",""),13,MUTED,false));space(summary,14);
            add(summary,text("ACTIVE MONTH",11,ACCENT,true));space(summary,5);
            Spinner monthSpinner=new Spinner(this);
            List<String> months=PlanStore.months(this);ArrayAdapter<String> monthsAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,months);
            monthSpinner.setAdapter(monthsAdapter);monthSpinner.setSelection(Math.max(0,months.indexOf(month)));
            monthSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
                boolean initial=true;
                @Override public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long id){
                    String selected=months.get(position);
                    if(initial){initial=false;return;}
                    if(!selected.equals(PlanStore.activeMonth(MainActivity.this))){PlanStore.selectMonth(MainActivity.this,selected);
                        try{chosenWeek=PlanStore.currentWeek(PlanStore.activePlan(MainActivity.this));}catch(Exception ignored){}
                        showHome();}
                }
                @Override public void onNothingSelected(android.widget.AdapterView<?> parent){}
            });
            add(summary,monthSpinner);
            add(summary,text("TRAINING WEEK",11,ACCENT,true));space(summary,4);
            Spinner weekSpinner=new Spinner(this);
            String[] weekLabels={"Week 1 · familiarise","Week 2 · build","Week 3 · progress","Week 4 · consolidate"};
            weekSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,weekLabels));
            weekSpinner.setSelection(Math.max(0,Math.min(3,chosenWeek-1)));
            weekSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
                @Override public void onItemSelected(android.widget.AdapterView<?> p,View v,int idx,long id){chosenWeek=idx+1;}
                @Override public void onNothingSelected(android.widget.AdapterView<?> p){}
            });
            add(summary,weekSpinner);space(summary,6);
            JSONArray progression=plan.getJSONArray("progression");
            add(summary,text(progression.getJSONObject(Math.min(3,chosenWeek-1)).optString("intensity",""),12,MUTED,false));
            space(column,8);
            add(column,text("YOUR STATION-BY-STATION SESSIONS",13,ACCENT,true));space(column,12);
            JSONArray sessions=plan.getJSONArray("sessions");
            for(int i=0;i<sessions.length();i++){
                JSONObject session=sessions.getJSONObject(i);
                String id=session.getString("id");
                LinearLayout c=card(column);
                add(c,text("SESSION  "+id+"  /  "+(i==0?"MONDAY":i==1?"WEDNESDAY":"FRIDAY"),12,ACCENT,true));space(c,5);
                add(c,text(session.optString("title",""),21,WHITE,true));space(c,4);
                add(c,text(session.optString("focus",""),13,MUTED,false));space(c,4);
                add(c,text("Fixed sets per exercise • no circuits across rooms",12,ACCENT,true));space(c,5);
                add(c,text(session.optString("description",""),12,MUTED,false));space(c,11);
                int seconds=WorkoutEngine.duration(WorkoutEngine.make(session,progression.getJSONObject(chosenWeek-1)));
                add(c,text("Estimated "+WorkoutEngine.clock(seconds)+"  ·  included station-change time",13,WHITE,true));space(c,12);
                LinearLayout actions=hbox();
                Button start=button("Start session",true);actions.addView(start,new LinearLayout.LayoutParams(0,dp(52),2f));
                Button details=button("Station plan",false);LinearLayout.LayoutParams detailLp=new LinearLayout.LayoutParams(0,dp(52),1.5f);detailLp.leftMargin=dp(8);actions.addView(details,detailLp);
                add(c,actions);
                start.setOnClickListener(v->startWorkout(id));details.setOnClickListener(v->showDetails(id));
            }
            add(column,text("WEEKLY RUNS + RECOVERY",13,ACCENT,true));space(column,12);
            LinearLayout runs=card(column);
            JSONArray schedule=plan.optJSONArray("schedule");
            if(schedule!=null)for(int i=0;i<schedule.length();i++){
                JSONObject scheduleDay=schedule.getJSONObject(i);
                if("gym".equals(scheduleDay.optString("type")))continue;
                add(runs,text(scheduleDay.optString("day","").toUpperCase()+"  ·  "+scheduleDay.optString("type","").toUpperCase(),12,WHITE,true));
                add(runs,text(scheduleDay.optString("note",""),12,MUTED,false));space(runs,10);
            }
            LinearLayout importCard=card(column);
            add(importCard,text("MONTHLY PROGRAMME UPDATES",14,ACCENT,true));space(importCard,8);
            add(importCard,text("Your app checks for new plans when opened, using a secure online programme feed. Workouts and history remain available offline. Your training notes are not uploaded.",13,WHITE,false));space(importCard,12);
            Button syncButton=button("Check for new monthly plan",true);add(importCard,syncButton);
            syncButton.setOnClickListener(v->{syncButton.setEnabled(false);syncButton.setText("Checking…");
                PlanSync.check(MainActivity.this,(ok,message)->{syncButton.setEnabled(true);syncButton.setText("Check for new monthly plan");
                    if(ok&&!showingWorkout){
                        try{chosenWeek=PlanStore.currentWeek(PlanStore.activePlan(MainActivity.this));}catch(Exception ignored){}
                        showHome();
                    }
                    new AlertDialog.Builder(MainActivity.this).setTitle(ok?"Programmes checked":"Update not available")
                        .setMessage(message).setPositiveButton("OK",null).show();
                });
            });
            space(importCard,9);
            Button manual=button("Import a backup plan file",false);add(importCard,manual);manual.setOnClickListener(v->chooseFile());
            space(importCard,9);
            Button source=button("Advanced: programme update source",false);add(importCard,source);
            source.setOnClickListener(v->editPlanSource());
            LinearLayout libraryCard=card(column);
            add(libraryCard,text("EXERCISE LIBRARY",14,ACCENT,true));space(libraryCard,8);
            add(libraryCard,text("Open quick guides with simple diagrams and local in-app demo GIFs for the movements in your current programme.",13,WHITE,false));space(libraryCard,10);
            Button library=button("Browse exercise guides",true);add(libraryCard,library);
            library.setOnClickListener(v->showDetails(todaySession!=null?todaySession:"A"));
            add(column,text("SESSION HISTORY & PROGRESS",13,ACCENT,true));space(column,12);
            LinearLayout historyCard=card(column);JSONArray history=PlanStore.history(this);
            Button share=button("Share progress for monthly review",true);add(historyCard,share);space(historyCard,10);
            share.setOnClickListener(v->shareProgress());
            Button restore=button("Restore saved history from clipboard",false);add(historyCard,restore);space(historyCard,12);
            restore.setOnClickListener(v->restoreProgressFromClipboard());
            if(history.length()==0)add(historyCard,text("Completed gym sessions appear here. History is stored locally, not uploaded.",13,MUTED,false));
            else {
                for(int j=history.length()-1;j>=Math.max(0,history.length()-12);j--){
                    final int index=j;JSONObject h=history.getJSONObject(j);
                    Button log=button(h.optString("date","").substring(0,Math.min(10,h.optString("date","").length()))
                            +" · Session "+h.optString("session")+" · "+WorkoutEngine.clock(h.optInt("elapsedSeconds")),false);
                    add(historyCard,log);space(historyCard,6);log.setOnClickListener(v->editHistory(index));
                }
            }
            add(column,text("Voice + Spotify and lock-screen workouts remain supported. Timers guide your pace; maintain good technique and tap Finish set when you complete your target reps early.",12,MUTED,false));
        }catch(Exception e){add(column,text("Programme error: "+e.getMessage(),14,Color.RED,false));}
    }
    private void startWorkout(String id){
        if(WorkoutService.latest!=null&&WorkoutService.latest.active){showWorkout();return;}
        Intent start=new Intent(this,WorkoutService.class).setAction(WorkoutService.START)
            .putExtra("month",PlanStore.activeMonth(this)).putExtra("session",id).putExtra("week",chosenWeek);
        try {startForegroundService(start);showWorkout();}
        catch(Exception e){toast("Android prevented the workout from starting: "+e.getMessage());}
    }
    private void command(String action){
        Intent i=new Intent(this,WorkoutService.class).setAction(action);
        startService(i);
    }
    private void showWorkout(){
        showingWorkout=true;createWorkoutScreen();
        add(column,text("FORGE COACH  /  LIVE WORKOUT",14,ACCENT,true));space(column,6);
        add(column,text("FIXED SETS  •  MUSIC + LOCK SCREEN FRIENDLY",12,MUTED,true));space(column,14);
        LinearLayout main=card(column);
        phaseLabel=text("READY",13,ACCENT,true);add(main,phaseLabel);space(main,7);
        nameLabel=text("Preparing workout…",24,WHITE,true);add(main,nameLabel);space(main,7);
        blockLabel=text("",12,MUTED,false);add(main,blockLabel);space(main,6);
        stationLabel=text("",12,ACCENT,true);add(main,stationLabel);space(main,9);

        autoDemoLabel=text("EXERCISE DEMONSTRATION",12,ACCENT,true);add(main,autoDemoLabel);space(main,7);
        liveGif=new GifView(this);
        liveGif.setAsset("gifs/generic.gif");
        displayedLiveGifAsset="gifs/generic.gif";
        liveGif.setBackground(surface(Color.rgb(17,25,33),BORDER,12));
        main.addView(liveGif,new LinearLayout.LayoutParams(-1,dp(205)));
        space(main,5);
        previewEquipmentLabel=text("",12,MUTED,false);add(main,previewEquipmentLabel);space(main,13);

        LinearLayout details=hbox();
        LinearLayout setsColumn=vbox();
        add(setsColumn,text("SETS",11,ACCENT,true));space(setsColumn,3);
        setsLabel=text("–",17,WHITE,true);add(setsColumn,setsLabel);
        details.addView(setsColumn,new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout repsColumn=vbox();
        add(repsColumn,text("TARGET",11,ACCENT,true));space(repsColumn,3);
        repsLabel=text("–",15,WHITE,true);add(repsColumn,repsLabel);
        details.addView(repsColumn,new LinearLayout.LayoutParams(0,-2,1.4f));
        LinearLayout weightColumn=vbox();
        add(weightColumn,text("LAST WEIGHT",11,ACCENT,true));space(weightColumn,3);
        weightLabel=text("Tap to log",14,WHITE,true);add(weightColumn,weightLabel);
        details.addView(weightColumn,new LinearLayout.LayoutParams(0,-2,1.1f));
        add(main,details);space(main,10);
        Button weightButton=button("Record / change weight (kg)",false);add(main,weightButton);
        weightButton.setOnClickListener(v->editCurrentWeight());space(main,12);

        FrameLayout dial=new FrameLayout(this);
        ring=new CountdownRingView(this);
        FrameLayout.LayoutParams ringLp=new FrameLayout.LayoutParams(dp(176),dp(176),Gravity.CENTER);
        dial.addView(ring,ringLp);
        LinearLayout timerCentre=vbox();timerCentre.setGravity(Gravity.CENTER);
        timerLabel=text("00:00",46,WHITE,true);timerLabel.setGravity(Gravity.CENTER_HORIZONTAL);add(timerCentre,timerLabel);
        TextView dialCaption=text("CURRENT INTERVAL",11,MUTED,true);dialCaption.setGravity(Gravity.CENTER_HORIZONTAL);add(timerCentre,dialCaption);
        dial.addView(timerCentre,new FrameLayout.LayoutParams(dp(175),dp(95),Gravity.CENTER));
        main.addView(dial,new LinearLayout.LayoutParams(-1,dp(188)));
        cueLabel=text("",13,MUTED,false);add(main,cueLabel);space(main,9);
        roundLabel=text("",13,WHITE,true);add(main,roundLabel);space(main,12);

        Button guideNow=button("Full exercise guide",false);
        add(main,guideNow);guideNow.setOnClickListener(v->showGuide(activeGuideExercise));
        space(main,14);

        LinearLayout nextCard=card(column);
        add(nextCard,text("UP NEXT",12,ACCENT,true));space(nextCard,5);
        nextLabel=text("",18,WHITE,true);add(nextCard,nextLabel);space(nextCard,7);
        overallLabel=text("",12,MUTED,false);add(nextCard,overallLabel);
        space(column,1);
        LinearLayout controls=hbox();
        pauseButton=button("Pause",true);
        controls.addView(pauseButton,new LinearLayout.LayoutParams(0,dp(54),1.1f));
        pauseButton.setOnClickListener(v->command(WorkoutService.PAUSE));
        skipButton=button("Finish set",false);
        LinearLayout.LayoutParams skipLp=new LinearLayout.LayoutParams(0,dp(54),1.5f);skipLp.leftMargin=dp(8);
        controls.addView(skipButton,skipLp);
        skipButton.setOnClickListener(v->command(WorkoutService.SKIP));
        Button plus=button("+15s",false);
        LinearLayout.LayoutParams plusLp=new LinearLayout.LayoutParams(0,dp(54),0.7f);plusLp.leftMargin=dp(8);
        controls.addView(plus,plusLp);plus.setOnClickListener(v->command(WorkoutService.ADD));
        add(bottomControls,controls);
        space(bottomControls,5);
        Button end=button("End session",false);end.setTextSize(12);end.setMinHeight(dp(36));
        add(bottomControls,end);
        end.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("End workout?")
                .setMessage("Ending now will discard this incomplete session from completed-session history.")
                .setNegativeButton("Keep going",null)
                .setPositiveButton("End session",(d,w)->{command(WorkoutService.END);showHome();}).show());
        refreshWorkout();
    }

    private void editCurrentWeight(){
        String exercise=activeGuideExercise;
        if(exercise==null||exercise.isEmpty()){toast("Start an exercise before logging weight.");return;}
        EditText input=new EditText(this);
        input.setSingleLine(true);
        input.setHint("e.g. 25");
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setText(PlanStore.lastWeight(this,exercise));
        new AlertDialog.Builder(this)
            .setTitle(exercise+" • weight in kg")
            .setMessage("Enter the load used for this exercise. For dumbbells, record the weight per hand. Your last value stays on your phone for your next session.")
            .setView(input)
            .setNegativeButton("Cancel",null)
            .setPositiveButton("Save",(d,w)->{
                PlanStore.saveWeight(this,exercise,input.getText().toString());
                weightLabel.setText(PlanStore.lastWeight(this,exercise).isEmpty()?"Tap to log":PlanStore.lastWeight(this,exercise)+" kg");
            }).show();
    }

    private void refreshWorkout(){
        if(!showingWorkout)return;
        WorkoutService.Snapshot s=WorkoutService.latest;
        if(s==null||!s.active)return;
        boolean isWork="WORK".equals(s.phase);
        phaseLabel.setText(s.paused?"PAUSED · "+s.phase:
                isWork?(s.straightSets?"STRENGTH  /  STRAIGHT SETS":"WORK INTERVAL"):
                "REST".equals(s.phase)?"REST  /  STAY AT THIS STATION":
                "CHANGE".equals(s.phase)?"CHANGE  /  MOVE TO NEXT MACHINE":"PREPARE NEXT BLOCK");
        nameLabel.setText(s.name);
        timerLabel.setText(WorkoutEngine.clock(s.remaining));
        cueLabel.setText(isWork && s.straightSets?"Do controlled reps, not a race against the clock. Finish the set when your target is reached.":s.cue);
        blockLabel.setText(s.block);
        stationLabel.setText(s.stationTotal>0?"Station "+s.stationNumber+" of "+s.stationTotal:"Equipment change / next section");

        String exercise=isWork?s.name:s.next;
        if(exercise==null||exercise.trim().isEmpty())exercise=s.name;
        activeGuideExercise=exercise;
        ExerciseGuide.Guide g=ExerciseGuide.forExercise(exercise);
        String gifAsset=g.gifAsset;
        if(liveGif!=null && !gifAsset.equals(displayedLiveGifAsset)){
            liveGif.setAsset(gifAsset);
            displayedLiveGifAsset=gifAsset;
        }
        if(autoDemoLabel!=null)autoDemoLabel.setText((isWork?"NOW  /  ":"NEXT  /  ")+exercise.toUpperCase(Locale.UK));
        if(previewEquipmentLabel!=null)previewEquipmentLabel.setText("EQUIPMENT  •  "+g.equipment);
        boolean isSets=isWork && s.straightSets;
        setsLabel.setText(isSets?""+s.round+" / "+s.rounds:"–");
        repsLabel.setText(isSets?s.targetReps:"Timed interval");
        String weight=PlanStore.lastWeight(this,exercise);
        weightLabel.setText(weight.isEmpty()?"Tap to log":weight+" kg");
        if(ring!=null)ring.setFraction(s.stepDuration>0 ? s.remaining/(float)s.stepDuration:1f);
        String setProgress="";
        if(isSets){
            for(int i=1;i<=s.rounds;i++)setProgress += i<s.round?"●  ":i==s.round?"◉  ":"○  ";
            roundLabel.setText("Set "+s.round+" of "+s.rounds+"    "+setProgress.trim());
        } else {
            roundLabel.setText("Interval "+s.stepIndex+" of "+s.totalSteps);
        }
        nextLabel.setText(s.next==null||s.next.isEmpty()?"Follow your next audio cue":s.next);
        overallLabel.setText("Approx. remaining: "+WorkoutEngine.clock(s.totalRemaining)+"  •  Week "+s.week);
        progress.setProgress(Math.max(0,Math.min(1000,(int)(1000f*(s.plannedTotal-s.totalRemaining)/Math.max(1,s.plannedTotal)))));
        pauseButton.setText(s.paused?"Resume workout":"Pause workout");
        if(skipButton!=null)skipButton.setText(isSets?"Finish this set":"Skip interval / rest");
    }

    private void showGuide(String exerciseName){
        ExerciseGuide.Guide g=ExerciseGuide.forExercise(exerciseName);
        ScrollView sc=new ScrollView(this);
        sc.setBackgroundColor(BG);
        LinearLayout wrap=vbox();
        wrap.setPadding(dp(18),dp(16),dp(18),dp(16));
        sc.addView(wrap);

        LinearLayout gifCard=vbox();
        gifCard.setPadding(dp(12),dp(12),dp(12),dp(12));
        gifCard.setBackground(surface(Color.rgb(22,31,31),BORDER,14));
        add(wrap,gifCard);
        add(gifCard,text("OFFLINE MOVEMENT DEMONSTRATION",12,ACCENT,true));
        space(gifCard,8);
        GifView gif=new GifView(this);
        gif.setAsset(g.gifAsset);
        gifCard.addView(gif,new LinearLayout.LayoutParams(-1,dp(245)));
        space(gifCard,6);
        add(gifCard,text("Simplified motion illustration. Confirm exact machine adjustments with gym staff.",11,MUTED,false));
        space(wrap,12);

        LinearLayout diagramCard=vbox();
        diagramCard.setPadding(dp(12),dp(12),dp(12),dp(12));
        diagramCard.setBackground(surface(Color.rgb(22,31,31),BORDER,14));
        add(wrap,diagramCard);
        add(diagramCard,text(g.name,20,WHITE,true));
        if(!g.tagline.isEmpty()){space(diagramCard,6);add(diagramCard,text(g.tagline,12,ACCENT,true));}
        space(diagramCard,10);
        ExerciseDiagramView diagram=new ExerciseDiagramView(this,g.diagramType);
        diagramCard.addView(diagram,new LinearLayout.LayoutParams(-1,dp(160)));
        space(diagramCard,8);
        add(diagramCard,text("Additional movement reference",11,MUTED,false));
        space(wrap,12);

        LinearLayout infoCard=vbox();
        infoCard.setPadding(dp(12),dp(12),dp(12),dp(12));
        infoCard.setBackground(surface(CARD,BORDER,14));
        add(wrap,infoCard);
        add(infoCard,text("Equipment / machine",12,ACCENT,true));space(infoCard,4);add(infoCard,text(g.equipment,14,WHITE,false));space(infoCard,10);
        add(infoCard,text("Set-up",12,ACCENT,true));space(infoCard,4);add(infoCard,text(g.setup,14,WHITE,false));space(infoCard,10);
        add(infoCard,text("How to do it",12,ACCENT,true));space(infoCard,4);add(infoCard,text(g.movement,14,WHITE,false));space(infoCard,10);
        add(infoCard,text("Key cues",12,ACCENT,true));space(infoCard,4);add(infoCard,text(g.cues,14,WHITE,false));space(infoCard,10);
        add(infoCard,text("Avoid",12,ACCENT,true));space(infoCard,4);add(infoCard,text(g.commonErrors,14,WHITE,false));
        if(!g.alternative.isEmpty()){space(infoCard,10);add(infoCard,text("Alternative",12,ACCENT,true));space(infoCard,4);add(infoCard,text(g.alternative,14,WHITE,false));}
        if(g.isFallback){space(infoCard,10);add(infoCard,text("A detailed guide for this movement has not been added yet. Use the machine notes above and ask gym staff if you are unsure which station to use.",12,MUTED,false));}

        space(wrap,12);
        Button close=button("Close",true);
        add(wrap,close);

        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Exercise guide").setView(sc).create();
        close.setOnClickListener(v->dialog.dismiss());
        dialog.show();
    }

    private void showDetails(String id){
        try {
            JSONObject plan=PlanStore.activePlan(this);
            JSONObject ses=PlanStore.session(plan,id);
            JSONArray blocks=ses.getJSONArray("blocks");
            JSONObject progression=plan.getJSONArray("progression").getJSONObject(chosenWeek-1);

            ScrollView sc=new ScrollView(this);
            sc.setBackgroundColor(BG);
            LinearLayout wrap=vbox();
            wrap.setPadding(dp(14),dp(10),dp(14),dp(10));
            sc.addView(wrap);

            for(int b=0;b<blocks.length();b++){
                JSONObject block=blocks.getJSONObject(b);
                String kind=block.optString("kind");
                int delta="conditioning".equals(kind)?progression.optInt("conditioningRoundDelta"):
                        ("strength".equals(kind)||"accessory".equals(kind))?progression.optInt("roundDelta"):0;
                int rounds=Math.max(1,block.getInt("rounds")+delta);

                LinearLayout blockCard=vbox();
                blockCard.setPadding(dp(10),dp(10),dp(10),dp(10));
                blockCard.setBackground(surface(Color.rgb(22,31,31),BORDER,12));
                LinearLayout.LayoutParams blockLp=new LinearLayout.LayoutParams(-1,-2);
                blockLp.bottomMargin=dp(12);
                wrap.addView(blockCard,blockLp);

                String header=block.getString("title").replace("circuit","stations").replace("Circuit","Stations");
                add(blockCard,text(header,16,WHITE,true));
                space(blockCard,4);
                boolean straight="strength".equals(kind)||"accessory".equals(kind);
                add(blockCard,text(straight?rounds+" sets per exercise • finish all sets before changing equipment":rounds+" timed rounds / intervals",12,ACCENT,true));
                if(straight)add(blockCard,text("Allow about "+("strength".equals(kind)?100:75)+"s recovery between sets and 75s for changing stations.",12,MUTED,false));
                space(blockCard,10);

                JSONArray stations=block.getJSONArray("stations");
                for(int i=0;i<stations.length();i++){
                    JSONObject ex=stations.getJSONObject(i);
                    String exName=ex.optString("name","");
                    LinearLayout exCard=vbox();
                    exCard.setPadding(dp(10),dp(10),dp(10),dp(10));
                    exCard.setBackground(surface(CARD,BORDER,10));
                    LinearLayout.LayoutParams exLp=new LinearLayout.LayoutParams(-1,-2);
                    exLp.bottomMargin=dp(8);
                    blockCard.addView(exCard,exLp);

                    add(exCard,text(exName,15,WHITE,true));
                    space(exCard,5);
                    ExerciseDiagramView thumb=new ExerciseDiagramView(this,ExerciseGuide.forExercise(exName).diagramType);
                    exCard.addView(thumb,new LinearLayout.LayoutParams(-1,dp(90)));
                    space(exCard,5);
                    add(exCard,text(("strength".equals(kind)||"accessory".equals(kind))?
                            rounds+" sets × "+WorkoutEngine.repsFor(exName,kind):ex.getInt("seconds")+" seconds",12,ACCENT,true));
                    String alt=ex.optString("alternative","");
                    if(!alt.isEmpty()){space(exCard,4);add(exCard,text("Alternative: "+alt,12,MUTED,false));}
                    space(exCard,8);
                    Button guide=button("Guide + demo",true);
                    add(exCard,guide);
                    guide.setOnClickListener(v->showGuide(exName));
                }
            }
            new AlertDialog.Builder(this).setTitle(ses.optString("title")+" · Week "+chosenWeek)
                    .setView(sc).setPositiveButton("Close",null).show();
        } catch(Exception e){toast("Cannot display exercise list: "+e.getMessage());}
    }

    private void editPlanSource(){
        EditText field=new EditText(this);field.setText(PlanSync.manifestUrl(this));
        field.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);
        field.setSingleLine(false);field.setPadding(dp(18),dp(16),dp(18),dp(16));
        new AlertDialog.Builder(this).setTitle("Programme source")
            .setMessage("Only change this if the Forge Coach update address changes. Monthly plans should download automatically after the programme repository is published.")
            .setView(field).setNegativeButton("Cancel",null)
            .setPositiveButton("Save",(dialog,which)->{
                try{PlanSync.setManifestUrl(this,field.getText().toString());toast("Programme source saved");}
                catch(Exception e){new AlertDialog.Builder(this).setMessage(e.getMessage()).setPositiveButton("OK",null).show();}
            }).show();
    }
    private void chooseFile(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/plain","application/octet-stream"});
        startActivityForResult(i,FILE_REQUEST);
    }
    @Override protected void onActivityResult(int req,int code,Intent data){
        super.onActivityResult(req,code,data);
        if(req!=FILE_REQUEST||code!=RESULT_OK||data==null||data.getData()==null)return;
        if(WorkoutService.latest!=null&&WorkoutService.latest.active){toast("End your current workout before importing a new plan.");return;}
        Uri uri=data.getData();
        try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){
            if(in==null)throw new Exception("Cannot open file");
            byte[] buf=new byte[8192];int n,total=0;
            while((n=in.read(buf))!=-1){total+=n;if(total>500_000)throw new Exception("Plan must be under 500KB");out.write(buf,0,n);}
            String raw=out.toString(StandardCharsets.UTF_8.name());
            String month=PlanStore.validate(raw);PlanStore.importPlan(this,raw);
            chosenWeek=PlanStore.currentWeek(PlanStore.activePlan(this));
            showHome();toast("Imported "+month+" plan. Previous plans and history retained.");
        }catch(Exception e){new AlertDialog.Builder(this).setTitle("Import unsuccessful")
                .setMessage("Plan was not applied. "+e.getMessage()).setPositiveButton("OK",null).show();}
    }
    private void restoreProgressFromClipboard(){
        if(WorkoutService.latest!=null && WorkoutService.latest.active){
            toast("End your workout before restoring history.");
            return;
        }
        android.content.ClipboardManager manager=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        if(manager==null || !manager.hasPrimaryClip()){
            toast("Copy your Forge Coach training export to the clipboard first.");
            return;
        }
        android.content.ClipData clip=manager.getPrimaryClip();
        if(clip==null || clip.getItemCount()<1){toast("Clipboard is empty.");return;}
        CharSequence value=clip.getItemAt(0).coerceToText(this);
        if(value==null){toast("Clipboard does not contain text.");return;}
        String raw=value.toString();
        try{
            JSONObject export=new JSONObject(raw);
            if(!"Forge Coach Training Review".equals(export.optString("exportType")))
                throw new Exception("Clipboard must contain a Forge Coach training export.");
            int count=export.getJSONArray("history").length();
            new AlertDialog.Builder(this)
                .setTitle("Restore training history?")
                .setMessage("Restore "+count+" saved session records? Existing records will be retained and duplicates skipped.")
                .setNegativeButton("Cancel",null)
                .setPositiveButton("Restore",(d,w)->{
                    try{
                        int added=PlanStore.restoreHistoryFromExport(this,raw);
                        int weights=PlanStore.restoreWeightsFromExport(this,new JSONObject(raw));
                        showHome();
                        toast("Restored "+added+" sessions and "+weights+" exercise weights.");
                    } catch(Exception e){
                        new AlertDialog.Builder(this).setTitle("Import unsuccessful")
                            .setMessage(e.getMessage()).setPositiveButton("OK",null).show();
                    }
                }).show();
        }catch(Exception e){
            new AlertDialog.Builder(this).setTitle("Cannot read export")
                .setMessage("Copy the complete JSON text generated by Share progress, then try again. "+e.getMessage())
                .setPositiveButton("OK",null).show();
        }
    }
    private void shareProgress(){
        try{
            JSONObject export=new JSONObject();export.put("exportType","Forge Coach Training Review");
            export.put("exportedAt",java.time.LocalDateTime.now().toString());
            export.put("history",PlanStore.history(this));
            export.put("activeMonth",PlanStore.activeMonth(this));
            export.put("exerciseWeights",PlanStore.exportWeights(this));
            Intent share=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT,"Forge Coach training history").putExtra(Intent.EXTRA_TEXT,export.toString(2));
            startActivity(Intent.createChooser(share,"Share training log"));
        }catch(Exception e){toast("Could not export history: "+e.getMessage());}
    }
    private void editHistory(int idx){
        JSONArray h=PlanStore.history(this);
        if(idx<0||idx>=h.length())return;
        JSONObject entry=h.optJSONObject(idx);
        EditText input=new EditText(this);input.setText(entry.optString("notes",""));
        input.setHint("Weights used, effort 1–10, form notes, substitutions");input.setMinLines(3);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        new AlertDialog.Builder(this).setTitle("Session "+entry.optString("session")+" · training notes")
                .setMessage("Log weight selections and effort. These notes help decide how to progress next month.")
                .setView(input).setNegativeButton("Cancel",null)
                .setPositiveButton("Save notes",(d,w)->{PlanStore.updateHistoryNotes(this,idx,input.getText().toString());showHome();})
                .show();
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override public void onBackPressed(){
        if(WorkoutService.latest!=null&&WorkoutService.latest.active){
            new AlertDialog.Builder(this).setTitle("Workout still running")
                .setMessage("You can lock your screen or return to the home screen. Voice guidance continues.")
                .setPositiveButton("Keep workout running",(d,w)->moveTaskToBack(true))
                .setNegativeButton("Stay here",null).show();
        }else super.onBackPressed();
    }
}
