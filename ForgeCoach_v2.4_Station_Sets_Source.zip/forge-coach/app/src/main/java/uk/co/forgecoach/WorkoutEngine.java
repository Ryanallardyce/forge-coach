package uk.co.forgecoach;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Station-first gym programming. Strength and accessory blocks use straight sets:
 * complete every set of a movement before changing equipment. The early-finish
 * control is available in the UI; timers remain automatic for lock-screen use.
 * Warmups/mobility remain timed sequences; continuous on-bike intervals retain
 * alternating effort/recovery without changing stations.
 */
public final class WorkoutEngine {
    private WorkoutEngine() {}

    public static final class Step {
        public final String phase, name, cue, next, block, kind, targetReps;
        public final int seconds, round, rounds, stationNumber, stationTotal;
        public final boolean switchSides, straightSets;
        Step(String phase,String name,String cue,String next,String block,String kind,String reps,
             int seconds,int round,int rounds,int stationNumber,int stationTotal,boolean sides,boolean straightSets){
            this.phase=phase;this.name=name;this.cue=cue;this.next=next;this.block=block;
            this.kind=kind;this.targetReps=reps;this.seconds=seconds;this.round=round;
            this.rounds=rounds;this.stationNumber=stationNumber;this.stationTotal=stationTotal;
            this.switchSides=sides;this.straightSets=straightSets;
        }
    }

    private static boolean sideSwitch(String cue){
        String lc=cue.toLowerCase(Locale.UK);
        return lc.contains("each side")||lc.contains("per side")||lc.contains("switch sides");
    }

    public static String repsFor(String name,String kind){
        String n=name.toLowerCase(Locale.UK);
        if(n.contains("carry"))return "30–40 sec carry";
        if(n.contains("pallof"))return "8–12 per side";
        if(n.contains("lunge")||n.contains("step-up"))return "8–10 per leg";
        if(n.contains("calf"))return "12–15 reps";
        if(n.contains("lateral")||n.contains("face pull")||n.contains("triceps")||n.contains("biceps"))return "10–15 reps";
        if(n.contains("romanian")||n.contains("pull-through"))return "8–10 reps";
        if(n.contains("leg press")&&n.contains("light"))return "10–12 easy reps";
        if(n.contains("hip thrust"))return "8–12 reps";
        if("strength".equals(kind))return "8–12 reps";
        if("accessory".equals(kind))return "10–12 reps";
        return "Timed interval";
    }

    private static boolean useStraightSets(String kind,JSONArray stations) {
        if("strength".equals(kind)||"accessory".equals(kind))return true;
        if(!"conditioning".equals(kind)||stations.length()<2)return false;
        boolean allBike=true;
        for(int i=0;i<stations.length();i++){
            if(!stations.optJSONObject(i).optString("name","").toLowerCase(Locale.UK).contains("bike")){
                allBike=false; break;
            }
        }
        return !allBike; // no repeated switching between cardio machine and floor station
    }

    public static List<Step> make(JSONObject session,JSONObject week) throws JSONException {
        List<Step> out=new ArrayList<>();
        JSONArray blocks=session.getJSONArray("blocks");
        for(int bi=0;bi<blocks.length();bi++) {
            JSONObject b=blocks.getJSONObject(bi);
            String kind=b.getString("kind");
            int originalRounds=b.getInt("rounds");
            int delta="conditioning".equals(kind)?week.optInt("conditioningRoundDelta"):
                    ("strength".equals(kind)||"accessory".equals(kind))?week.optInt("roundDelta"):0;
            int rounds=Math.max(1,Math.min(8,originalRounds+delta));
            JSONArray stations=b.getJSONArray("stations");
            String block=b.optString("title","").replace("circuit", "station sets").replace("Circuit", "Station sets");
            boolean straight=useStraightSets(kind,stations);
            if(straight){
                for(int i=0;i<stations.length();i++){
                    JSONObject s=stations.getJSONObject(i);
                    String name=s.getString("name"), cue=s.optString("cue","");
                    boolean repsMode="strength".equals(kind)||"accessory".equals(kind);
                    int workSecs=s.getInt("seconds");
                    if(repsMode){
                        String lower=name.toLowerCase(Locale.UK);
                        if(lower.contains("pallof")||lower.contains("lunge")||lower.contains("step-up"))
                            workSecs=Math.max(75,workSecs); // allow both sides without rushing
                        else if(lower.contains("carry"))
                            workSecs=Math.max(40,workSecs);
                        else
                            workSecs=Math.max(55,workSecs);
                    }
                    int rest="strength".equals(kind)?Math.max(100,b.optInt("restBetweenRoundsSeconds")):
                            "accessory".equals(kind)?Math.max(75,b.optInt("restBetweenRoundsSeconds")):
                            Math.max(35,b.optInt("restBetweenRoundsSeconds"));
                    for(int r=1;r<=rounds;r++){
                        out.add(new Step("WORK",name,cue,"",block,kind,repsMode?repsFor(name,kind):"Timed interval",
                                workSecs,r,rounds,i+1,stations.length(),sideSwitch(cue),repsMode));
                        if(r<rounds && rest>0){
                            out.add(new Step("REST","Rest at this station","Recover and stay at "+name,
                                    name,block,kind,"",rest,r,rounds,i+1,stations.length(),false,false));
                        }
                    }
                    if(i<stations.length()-1){
                        String next=stations.getJSONObject(i+1).getString("name");
                        int change="strength".equals(kind)||"accessory".equals(kind)?
                                Math.max(75,b.getInt("stationTransitionSeconds")):
                                Math.max(65,b.getInt("stationTransitionSeconds"));
                        out.add(new Step("CHANGE","Move to next station","Change rooms / find equipment if needed",
                                next,block,kind,"",change,0,0,i+1,stations.length(),false,false));
                    }
                }
            } else {
                for(int r=1;r<=rounds;r++){
                    for(int i=0;i<stations.length();i++){
                        JSONObject s=stations.getJSONObject(i);
                        String name=s.getString("name"),cue=s.optString("cue","");
                        out.add(new Step("WORK",name,cue,"",block,kind,"Timed interval",s.getInt("seconds"),
                                r,rounds,i+1,stations.length(),sideSwitch(cue),false));
                        if(i<stations.length()-1){
                            int change=b.getInt("stationTransitionSeconds");
                            if(change>0){
                                out.add(new Step("CHANGE","Change station","Prepare the next movement",
                                        stations.getJSONObject(i+1).getString("name"),block,kind,"",change,r,rounds,i+1,stations.length(),false,false));
                            }
                        } else if(r<rounds){
                            int rest=b.getInt("restBetweenRoundsSeconds");
                            if(rest>0){
                                out.add(new Step("REST","Recover","Breathe and reset",
                                        stations.getJSONObject(0).getString("name"),block,kind,"",rest,r,rounds,i+1,stations.length(),false,false));
                            }
                        }
                    }
                }
            }
            if(bi<blocks.length()-1){
                JSONObject next=blocks.getJSONObject(bi+1);
                int move=b.getInt("blockTransitionSeconds");
                if("strength".equals(kind)||"accessory".equals(kind)||"conditioning".equals(kind))move=Math.max(70,move);
                if("warmup".equals(kind))move=Math.max(85,move);
                if(move>0)out.add(new Step("SETUP","Set up next block",next.optString("title",""),
                        next.getJSONArray("stations").getJSONObject(0).getString("name"),
                        block,kind,"",move,0,0,0,0,false,false));
            }
        }
        if(out.isEmpty())throw new JSONException("Session has no intervals.");
        return out;
    }

    public static int duration(List<Step> steps){int t=0;for(Step s:steps)t+=s.seconds;return t;}
    public static String clock(int sec){return String.format(Locale.UK,"%02d:%02d",sec/60,sec%60);}
}
