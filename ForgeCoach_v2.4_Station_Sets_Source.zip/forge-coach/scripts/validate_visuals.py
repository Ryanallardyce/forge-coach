#!/usr/bin/env python3
"""Validate every bundled movement has an exercise-specific animated GIF."""
from pathlib import Path
import json,re,sys

project=Path(__file__).resolve().parents[1]
plan=json.loads((project/'app/src/main/assets/default-plan.json').read_text())
assets=project/'app/src/main/assets/gifs'
guide=(project/'app/src/main/java/uk/co/forgecoach/ExerciseGuide.java').read_text()
all_exercises={station['name'] for session in plan['sessions'] for block in session['blocks'] for station in block['stations']}
missing=[]
for name in sorted(all_exercises):
    slug=re.sub(r'[^a-z0-9]+','_',name.lower()).strip('_')
    f=assets/f'exercise_{slug}.gif'
    if not f.exists() or f.stat().st_size<100:
        missing.append(str(f))
    if ('put("'+name+'",') not in guide:
        missing.append('Guide: '+name)
if missing:
    print('\n'.join(missing),file=sys.stderr)
    sys.exit(1)
print(f'Exercise animation coverage OK: {len(all_exercises)} unique exercises')
