# Forge Coach v2.5 — exact visual exercise library

Programme start: **Monday 23 November 2026**. The library covers all 38 distinct named movements in Sessions A/B/C, including warm-ups, conditioning and cooldowns.

## Visual quality and coverage

The app contains 76 offline JPEGs: a compact live-workout reference and a full exercise guide for each of 38 named movements. For 16 exercise names, original generated high-quality start/finish photos are used (including 4 of the 6 warm-ups). Another 9 have exercise-matched compact photos; 13 have large equipment-specific start/finish text-form cards rather than an unreliable or incorrect photo. No stickman GIFs remain.

The previous v2.4 workout-start crash was caused by a progress view that was updated without initialisation. v2.5 allocates the progress bar before session rendering and guards updates against null.

## Warm-up and preparation

- **Alternating reverse lunges** — Realistic warm-up start/finish photographic guide
- **Arm circles and shoulder rolls** — Realistic warm-up start/finish photographic guide
- **Bodyweight squats** — Realistic warm-up start/finish photographic guide
- **Fast walk or easy cycle** — Compact exercise-matched photograph
- **Hip hinge drill** — Realistic warm-up start/finish photographic guide
- **Standing trunk rotations** — Equipment-specific start/finish instruction card

## Main strength exercises

- **Alternating step-ups** — Realistic start/finish photographic guide
- **Cable pull-through (light)** — Equipment-specific start/finish instruction card
- **Chest-supported row** — Equipment-specific start/finish instruction card
- **Dumbbell Romanian deadlift** — Realistic start/finish photographic guide
- **Dumbbell bench press** — Realistic start/finish photographic guide
- **Hip thrust machine** — Realistic start/finish photographic guide
- **Incline dumbbell press** — Equipment-specific start/finish instruction card
- **Lat pulldown** — Realistic start/finish photographic guide
- **Lat pulldown or assisted pull-up** — Realistic start/finish photographic guide
- **Leg press** — Realistic start/finish photographic guide
- **Light leg press** — Realistic start/finish photographic guide
- **Machine chest press** — Compact exercise-matched photograph

## Resistance and accessory work

- **Alternating reverse lunges** — Realistic warm-up start/finish photographic guide
- **Cable face pull** — Equipment-specific start/finish instruction card
- **Dumbbell biceps curl** — Equipment-specific start/finish instruction card
- **Dumbbell lateral raises** — Equipment-specific start/finish instruction card
- **Farmer carry** — Equipment-specific start/finish instruction card
- **Pallof press** — Realistic start/finish photographic guide
- **Rope triceps pressdown** — Compact exercise-matched photograph
- **Seated cable row** — Realistic start/finish photographic guide
- **Seated leg curl** — Realistic start/finish photographic guide
- **Seated shoulder press** — Realistic start/finish photographic guide

## Conditioning and cardiovascular

- **Bike · easy spin** — Compact exercise-matched photograph
- **Dead bug** — Equipment-specific start/finish instruction card
- **Standing calf raises** — Equipment-specific start/finish instruction card
- **Stationary bicycle · brisk** — Compact exercise-matched photograph
- **Stationary bike · moderate effort** — Compact exercise-matched photograph
- **Stationary bike · steady hard** — Compact exercise-matched photograph

## Mobility and cooldown

- **Calf stretch** — Equipment-specific start/finish instruction card
- **Doorway chest stretch** — Equipment-specific start/finish instruction card
- **Half-kneeling hip flexor stretch** — Compact exercise-matched photograph
- **Hamstring stretch** — Compact exercise-matched photograph
- **Slow nasal breathing** — Equipment-specific start/finish instruction card

## Testing and limitations

- Static regression tests assert all 38 mappings, all 76 JPGs, the progress-bar crash fix and removal of stickman GIFs.
- Java source has been parsed for syntax errors; a full Android build is performed on GitHub Actions after the source ZIP is uploaded.
- Some movement photos are cropped from a multi-exercise illustrated sheet and are lower-resolution than the principal generated exercise guides.
- For 13 movements with no verified pose-matched photograph, the app explicitly shows set-up and movement instruction cards; future releases can replace these with realistic demonstrations once they are verified.
- Generated imagery is a reference, not a substitute for machine instructions or help from qualified staff.
- The release uses the same encrypted release signing key as v2.4 and versionCode 8, so Android should update in place and preserve workout data.

