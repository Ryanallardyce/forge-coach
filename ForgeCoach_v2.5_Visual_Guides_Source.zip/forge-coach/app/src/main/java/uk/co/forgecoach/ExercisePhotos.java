package uk.co.forgecoach;

import java.util.Locale;
import java.util.HashMap;
import java.util.Map;

/** All exercise photos are bundled locally and available without internet access. */
public final class ExercisePhotos {
    private static final Map<String,String> KEY=new HashMap<>();
    static {
        KEY.put("alternating reverse lunges","alternating_reverse_lunges");
        KEY.put("alternating step-ups","alternating_step_ups");
        KEY.put("arm circles and shoulder rolls","arm_circles_and_shoulder_rolls");
        KEY.put("bike · easy spin","bike_easy_spin");
        KEY.put("bodyweight squats","bodyweight_squats");
        KEY.put("cable face pull","cable_face_pull");
        KEY.put("cable pull-through (light)","cable_pull_through_light");
        KEY.put("calf stretch","calf_stretch");
        KEY.put("chest-supported row","chest_supported_row");
        KEY.put("dead bug","dead_bug");
        KEY.put("doorway chest stretch","doorway_chest_stretch");
        KEY.put("dumbbell romanian deadlift","dumbbell_romanian_deadlift");
        KEY.put("dumbbell bench press","dumbbell_bench_press");
        KEY.put("dumbbell biceps curl","dumbbell_biceps_curl");
        KEY.put("dumbbell lateral raises","dumbbell_lateral_raises");
        KEY.put("farmer carry","farmer_carry");
        KEY.put("fast walk or easy cycle","fast_walk_or_easy_cycle");
        KEY.put("half-kneeling hip flexor stretch","half_kneeling_hip_flexor_stretch");
        KEY.put("hamstring stretch","hamstring_stretch");
        KEY.put("hip hinge drill","hip_hinge_drill");
        KEY.put("hip thrust machine","hip_thrust_machine");
        KEY.put("incline dumbbell press","incline_dumbbell_press");
        KEY.put("lat pulldown","lat_pulldown");
        KEY.put("lat pulldown or assisted pull-up","lat_pulldown_or_assisted_pull_up");
        KEY.put("leg press","leg_press");
        KEY.put("light leg press","light_leg_press");
        KEY.put("machine chest press","machine_chest_press");
        KEY.put("pallof press","pallof_press");
        KEY.put("rope triceps pressdown","rope_triceps_pressdown");
        KEY.put("seated cable row","seated_cable_row");
        KEY.put("seated leg curl","seated_leg_curl");
        KEY.put("seated shoulder press","seated_shoulder_press");
        KEY.put("slow nasal breathing","slow_nasal_breathing");
        KEY.put("standing calf raises","standing_calf_raises");
        KEY.put("standing trunk rotations","standing_trunk_rotations");
        KEY.put("stationary bicycle · brisk","stationary_bicycle_brisk");
        KEY.put("stationary bike · moderate effort","stationary_bike_moderate_effort");
        KEY.put("stationary bike · steady hard","stationary_bike_steady_hard");
    }
    private static String stem(String exercise) {
        if(exercise==null)return "";
        String key=KEY.get(exercise.trim().toLowerCase(Locale.UK));
        return key==null?"":key;
    }
    public static String previewAsset(String exercise) {
        String s=stem(exercise);
        return s.isEmpty()?"cards/unknown_exercise_preview.jpg":"cards/"+s+"_preview.jpg";
    }
    public static String fullAsset(String exercise) {
        String s=stem(exercise);
        return s.isEmpty()?"cards/unknown_exercise_full.jpg":"cards/"+s+"_full.jpg";
    }
}
