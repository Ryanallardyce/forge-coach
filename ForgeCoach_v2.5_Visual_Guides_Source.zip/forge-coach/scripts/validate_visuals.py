#!/usr/bin/env python3
"""v2.5 contract: all named movements have offline JPG previews/full guides.
Also guards against the v2.4 null-progress-bar startup crash.
"""
from pathlib import Path
import json,re,sys

project=Path(__file__).resolve().parents[1]
plan=json.loads((project/'app/src/main/assets/default-plan.json').read_text())
assets=project/'app/src/main/assets/cards'
source=(project/'app/src/main/java/uk/co/forgecoach/MainActivity.java').read_text()
lookup=(project/'app/src/main/java/uk/co/forgecoach/ExercisePhotos.java').read_text()
guide=(project/'app/src/main/java/uk/co/forgecoach/ExerciseGuide.java').read_text()
all_exercises={s['name'] for ses in plan['sessions'] for block in ses['blocks'] for s in block['stations']}
issues=[]
for name in sorted(all_exercises):
    slug=re.sub(r'[^a-z0-9]+','_',name.lower()).strip('_')
    for suffix in ('preview','full'):
        f=assets/(slug+'_'+suffix+'.jpg')
        if not f.is_file() or f.stat().st_size < 1500:
            issues.append('Missing/empty image: '+str(f));continue
        raw=f.read_bytes()
        if not (raw[:2]==b'\xff\xd8' and raw[-2:]==b'\xff\xd9'):
            issues.append('Not a complete JPG: '+str(f))
    if ('put("'+name+'",') not in guide:issues.append('Missing exercise guide: '+name)
    if ('KEY.put("'+name.lower()+'",') not in lookup:issues.append('Missing image lookup: '+name)
for suffix in ('preview','full'):
    if not (assets/('unknown_exercise_'+suffix+'.jpg')).is_file():issues.append('Missing fallback image')
if 'progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal)' not in source:
    issues.append('Missing progress-bar initialisation: known v2.4 startup crash')
if 'if(progress!=null)progress.setProgress(' not in source:
    issues.append('Missing progress-bar defensive guard')
if source.index('progress=new ProgressBar')>source.index('refreshWorkout();\n    }'):
    issues.append('Progress bar initialises after workout refresh')
if 'new GifView(this)' in source or 'new ExerciseDiagramView(this)' in source:
    issues.append('Stickman visual still used')
if (project/'app/src/main/assets/gifs').exists():
    issues.append('Old stickman GIF assets are still bundled')
if issues:
    print('\n'.join(issues),file=sys.stderr);sys.exit(1)
print(f'v2.5 visual coverage and session-start regression checks PASS: {len(all_exercises)} movements, {len(all_exercises)*2} images')
