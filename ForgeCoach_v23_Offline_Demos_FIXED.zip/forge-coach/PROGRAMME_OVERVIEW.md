# Forge Coach — four-week foundation block

**Starts:** Monday 9 November 2026  
**Runs:** Every Tuesday (easy) and Saturday (long, easy)  
**Gym:** Monday / Wednesday / Friday  
**Recover:** Thursday and Sunday  
**Primary outcomes:** body composition, muscular strength, movement quality, aerobic fitness and long-term adherence.

## Training calendar

| Week | Dates | Strength target | Running/recovery target |
|---|---|---|---|
| 1 | 9–15 Nov | RPE ~6–7; learn stations and movement patterns; fewer rounds | Tue conversational run; Sat long easy run; reduce duration if sore |
| 2 | 16–22 Nov | RPE ~7; normal programme volume | Maintain two mostly easy runs |
| 3 | 23–29 Nov | RPE 7–8; modest weight increase only where form permits | Maintain quality, do not add hard intervals automatically |
| 4 | 30 Nov–6 Dec | RPE 6–7; reduced volume to consolidate | Continue two manageable runs; assess progress and fatigue |

## Sessions

- **Gym A — Monday:** warm-up; leg press and lat pulldown pair; dumbbell bench press and Romanian deadlift pair; cable row and reverse lunges; low-impact conditioning; hip/hamstring/chest/calf mobility.
- **Gym B — Wednesday:** warm-up; step-ups and chest-supported rows; hip thrust and incline dumbbell press; shoulder press and leg curl; carries and Pallof press; controlled aerobic work; mobility.
- **Gym C — Friday:** warm-up; **light leg press** and lat pulldown; chest press and light cable pull-through; lateral raises, face pulls, biceps and triceps; **moderate** bicycle interval finish; mobility. No hard leg finishers before Saturday.

Workout intervals are defined per station in the included JSON programme, with separate station changes, between-round rests and block setup. Heavy lifting movements should be controlled rather than treating 45 seconds as an all-out sprint. If the equipment is taken, **pause** and adjust the setup period instead of skipping recovery.

### Running

**Tuesday:** conversational easy aerobic run, initially roughly 35–50 minutes, aligned with current running plan.  
**Saturday:** long easy run, initially approximately 60–80 minutes if comfortably tolerated; adapt to existing Runna guidance and weekly fatigue.  
Five sessions per week does **not** mean five high-intensity sessions; limit genuinely high-intensity efforts until recovery and training tolerance are established.

### Training metrics to capture

- Weights and equipment choices for each major lift; perceived effort (RPE) and any early stops.
- Weekly waist measurement and 3–4 morning body weights as averages, rather than reacting to daily fluctuations.
- Sleep, leg soreness, running performance and adherence.
- Review after four weeks before publishing the December plan (start date 7 December).

### Evidence

- ACSM 2026 resistance training position stand: https://pubmed.ncbi.nlm.nih.gov/41843416/
- Concurrent endurance + resistance training: https://pmc.ncbi.nlm.nih.gov/articles/PMC12946880/
- UK Chief Medical Officers physical activity guidelines: https://www.gov.uk/government/publications/physical-activity-guidelines-uk-chief-medical-officers-report/uk-chief-medical-officers-physical-activity-guidelines
