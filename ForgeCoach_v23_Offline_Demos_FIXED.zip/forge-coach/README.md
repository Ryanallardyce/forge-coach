# Forge Coach 2.1 — personal Android fitness coach

**Current status: Android source project, not a compiled APK.** The program files and feed pass offline checks. The app has not yet been compiled with the Android SDK or tested on a Samsung phone. Workouts should not be trusted with a locked display until a phone test confirms spoken cues and timer reliability.

## What it does

- On-device, timed workout coach with interval countdowns, spoken cues, station changes, recovery, halfway side swaps and low-impact finishers.
- Native Android **foreground service**, ongoing workout notification, pause/resume/skip and wake lock while a session runs. Designed for screen-off use, subject to Samsung battery and Bluetooth testing.
- Today's training displayed prominently: **Mon Gym A, Tue easy run, Wed Gym B, Thu recovery, Fri Gym C, Sat long easy run, Sun rest**.
- A four-week foundation programme beginning **Monday 9 November 2026**. Three gym sessions weekly, two fixed running days. First week reduced load, weeks 2–3 build, week 4 consolidation.
- Downloadable monthly plans via an HTTPS `plans/index.json` feed. New validated JSON plans are cached **offline**. Manual import remains available as a fallback.
- Completed-session history and editable notes stay **on the phone**. There is no account, advertisement, analytics, progress upload or remote control of the device.

## One human step needed before the installer can be built

The GitHub account is connected, but the account currently has **no repository**. The owner must first create one in the GitHub interface:

1. Visit [github.com/new](https://github.com/new) while signed in.
2. Name the repository exactly **`forge-coach`**.
3. Select **Public**, because the app's read-only workout plans must be accessible anonymously. The repository will contain app source and generic workouts **only**, not private health records, passwords or personal logs.
4. Tick **Add a README** to initialise the main branch. Leave the other optional settings at their defaults. The README will be replaced with this project’s instructions when the files are uploaded.
5. Return to ChatGPT with **“The forge-coach repository is created.”** ChatGPT can then use the GitHub connector to upload the source and workflow and run the build where permitted. The owner does not need Android Studio, a terminal or coding knowledge.

We cannot build the Android APK in the current environment because Android SDK/Gradle build dependencies aren't installed, and external downloads are blocked. GitHub Actions will build it using an Android runner once source has been uploaded.

## Plan updates without importing files

By default the app checks:

`https://raw.githubusercontent.com/Ryanallardyce/forge-coach/main/plans/index.json`

It checks automatically about once a day after opening the app, or when **Check for new monthly plan** is tapped. It downloads the manifest and JSON plans over HTTPS, verifies each SHA-256 hash and checks the plan schema before saving them locally. When a newer plan's start date arrives it can become the active plan. It never changes the current workout mid-session.

To publish a new month, a reviewed plan is added as `plans/YYYY-MM.json` and the hash in `plans/index.json` is updated. In this project, `scripts/publish_plan.py` prepares both files. ChatGPT can commit updates to the connected repository with explicit user instruction, provided the connection remains authorised and the write actions are available.

**Only November is published.** December and January files are drafts and should be revised against the preceding month's training record first. The public programme feed is a simple distribution mechanism, not a personalised account or a secure health-data service.

## Android installer and continuity

The included `.github/workflows/build-apk.yml` builds a **debug APK** using a GitHub-hosted Android/Gradle runner and saves it as a downloadable workflow artifact. It is for personal sideloaded testing, not Google Play. The repository Actions tab is the first place to check build output and any compilation failures.

**Important:** GitHub runners may use different debug signing keys between builds. A future updated APK may not install over the earlier build unless a stable private signing key is configured. Monthly programme updates do **not** require app reinstallations. For a sustainable production-style update process, implement stable release signing backed by GitHub secrets before distributing new app versions.

**Phone test checklist:** start a workout, pair Bluetooth headphones, lock screen for 2–5 minutes, check audio and timer, pause from notification, resume, skip, answer a call, disconnect/reconnect Bluetooth, confirm app doesn't freeze. Samsung may require excluding the app from sleeping-app/battery optimisation restrictions.

## Program structure

- Full-body timed strength circuits with alternating muscle-group pairs, adequate transitions and between-round recovery.
- Mon A: moderate lower-body and upper-body strength; Tue run remains easy.
- Wed B: functional full-body strength and posterior-chain work; Thu recovery.
- Fri C: upper-body emphasis, **light legs** and a moderate finisher; protects Sat long run.
- Exercise time is **a ceiling, not permission to rush form or move constantly**. Stop a set early if form changes. Select weights that preserve approximately 2–4 repetitions in reserve in week 1 and 1–3 in weeks 2–3.
- Optional mobility and walking on recovery days. Fat loss requires sustainable nutrition and adequate sleep; spot reduction is not physiologically achievable.

November plan: `app/src/main/assets/default-plan.json` and `plans/2026-11.json`.

Offline structural checks:

```bash
python3 scripts/validate_plan.py app/src/main/assets/default-plan.json Forge_Coach_2026-12.json Forge_Coach_2027-01.json
python3 scripts/test_feed.py
```

## Privacy and limitations

Only generic monthly workout plans are published publicly. Logs and notes remain on-device and are lost if the app is uninstalled or its storage is cleared unless manually exported. The app cannot receive private ChatGPT messages or grant ChatGPT remote access. A plan is published only via the connected GitHub repository, not silently or automatically by an ongoing AI agent.

This code has not been built or instrumented in Android Studio, and actual foreground service behaviour, notification permissions, Bluetooth TTS audio, battery policy and process recreation require real-device validation.
