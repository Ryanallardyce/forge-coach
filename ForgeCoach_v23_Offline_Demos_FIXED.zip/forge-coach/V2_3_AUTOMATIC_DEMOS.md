# Forge Coach v2.3 — automatic exercise demos and voice warnings

This replaces the earlier v2.3 source ZIP and retains the timed workout programme, programme synchronisation and offline workout history.

## Automatic GIFs
- The current exercise's local GIF appears automatically during WORK intervals.
- During REST, CHANGE and SETUP, the GIF previews the next exercise.
- The GIF changes only when the exercise changes, avoiding reloads every second.
- The diagrams and animations are simplified original schematics, not filmed exercise demonstrations or accurate replicas of your gym's machinery. Read the corresponding equipment and setup guide, and ask gym staff about unfamiliar equipment.
- Detailed instructions remain available via Current guide + demo.

## Spoken cues
- In work intervals >=15 seconds, a ten-second warning plays; at five seconds (interval >=10 seconds), another warning plays.
- During recovery and station changes the ten-second warning names the next exercise; at five seconds it says 'Five seconds. Get ready'.
- The existing 3, 2, 1 countdown and start-of-exercise announcements remain active.
- Speech is handled by the background foreground service and can continue with the screen locked; GIFs are only visible with the screen on.

## Installation and testing
- Same Android application ID, uk.co.forgecoach; versionCode increased from 3 to 6, versionName 2.3.
- Install over v2.1 rather than uninstalling it; uninstalling will discard local workout history.
- The existing GitHub workflow currently produces a DEBUG-signed APK. A debug key generated on each runner may change, so **updating an existing APK can fail with a signing-certificate mismatch**. If that happens, export all workout history before any reinstall and arrange a persistent signing key for future updates.
- Verify live GIF, rest previews, headset countdowns, screen-off behaviour and local history retention on the Samsung phone after compilation.
