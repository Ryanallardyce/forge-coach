package uk.co.forgecoach;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

public class ExerciseDiagramView extends View {
    private final Paint accent = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint white = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint muted = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private String type = "generic";

    public ExerciseDiagramView(Context c, String diagramType) {
        super(c);
        init(diagramType);
    }
    public ExerciseDiagramView(Context c, AttributeSet attrs) {
        super(c, attrs);
        init("generic");
    }
    private void init(String diagramType) {
        type = diagramType == null ? "generic" : diagramType;
        accent.setColor(Color.rgb(190,246,103));
        accent.setStyle(Paint.Style.FILL);
        white.setColor(Color.rgb(242,246,240));
        white.setStyle(Paint.Style.STROKE);
        white.setStrokeWidth(dp(3));
        white.setStrokeCap(Paint.Cap.ROUND);
        muted.setColor(Color.rgb(90,110,105));
        muted.setStyle(Paint.Style.STROKE);
        muted.setStrokeWidth(dp(4));
        muted.setStrokeCap(Paint.Cap.ROUND);
        stroke.setColor(Color.rgb(52,68,65));
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(2));
    }

    private float dp(float v){ return getResources().getDisplayMetrics().density * v; }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth();
        float h = getHeight();
        c.drawRoundRect(dp(4), dp(4), w-dp(4), h-dp(4), dp(14), dp(14), stroke);
        drawFloor(c, h);
        switch (type) {
            case "bike": drawBike(c,w,h); break;
            case "stretch": drawStretch(c,w,h); break;
            case "arm_circles": case "trunk_rotation": case "calf_raise": case "hip_flexor_stretch": case "hamstring_stretch": case "doorway_chest_stretch": case "calf_stretch": drawStretch(c,w,h); break;
            case "squat": drawSquat(c,w,h); break;
            case "hinge": drawHinge(c,w,h); break;
            case "lunge": drawLunge(c,w,h); break;
            case "machine_leg_press": drawLegPress(c,w,h); break;
            case "pull_vertical": drawLatPulldown(c,w,h); break;
            case "press_horizontal": drawBenchPress(c,w,h); break;
            case "pull_horizontal": drawRow(c,w,h); break;
            case "core": drawDeadBug(c,w,h); break;
            case "step_up": drawStepUp(c,w,h); break;
            case "hip_thrust": drawHipThrust(c,w,h); break;
            case "press_vertical": drawShoulderPress(c,w,h); break;
            case "leg_curl": drawLegCurl(c,w,h); break;
            case "carry": drawCarry(c,w,h); break;
            case "pallof": drawPallof(c,w,h); break;
            case "lateral_raise": drawLateralRaise(c,w,h); break;
            case "face_pull": drawFacePull(c,w,h); break;
            case "curl": drawCurl(c,w,h); break;
            case "pressdown": drawPressdown(c,w,h); break;
            case "breathing": drawBreathing(c,w,h); break;
            default: drawGeneric(c,w,h); break;
        }
    }

    private void drawFloor(Canvas c,float h){ c.drawLine(dp(16),h-dp(20),getWidth()-dp(16),h-dp(20),muted); }
    private void head(Canvas c,float x,float y){ c.drawCircle(x,y,dp(10),white); }
    private void body(Canvas c,float x1,float y1,float x2,float y2){ c.drawLine(x1,y1,x2,y2,white); }
    private void joint(Canvas c,float x,float y){ c.drawCircle(x,y,dp(4),accent); }
    private void arrow(Canvas c,float x1,float y1,float x2,float y2){
        c.drawLine(x1,y1,x2,y2,accent);
        Path p=new Path();
        float dx=x2-x1, dy=y2-y1;
        double ang=Math.atan2(dy,dx);
        float s=dp(8);
        p.moveTo(x2,y2);
        p.lineTo((float)(x2-s*Math.cos(ang-Math.PI/6)),(float)(y2-s*Math.sin(ang-Math.PI/6)));
        p.moveTo(x2,y2);
        p.lineTo((float)(x2-s*Math.cos(ang+Math.PI/6)),(float)(y2-s*Math.sin(ang+Math.PI/6)));
        c.drawPath(p,accent);
    }
    private void machineBlock(Canvas c,float l,float t,float r,float b){ c.drawRoundRect(l,t,r,b,dp(8),dp(8),muted); }

    private void drawGeneric(Canvas c,float w,float h){
        head(c,w*0.28f,h*0.28f); body(c,w*0.28f,h*0.38f,w*0.28f,h*0.62f);
        body(c,w*0.28f,h*0.45f,w*0.18f,h*0.56f); body(c,w*0.28f,h*0.45f,w*0.38f,h*0.54f);
        body(c,w*0.28f,h*0.62f,w*0.20f,h*0.82f); body(c,w*0.28f,h*0.62f,w*0.36f,h*0.82f);
        machineBlock(c,w*0.58f,h*0.25f,w*0.82f,h*0.78f); arrow(c,w*0.40f,h*0.45f,w*0.57f,h*0.45f);
    }
    private void drawBike(Canvas c,float w,float h){
        c.drawCircle(w*0.28f,h*0.72f,dp(18),muted); c.drawCircle(w*0.55f,h*0.72f,dp(18),muted);
        c.drawLine(w*0.28f,h*0.72f,w*0.44f,h*0.55f,muted); c.drawLine(w*0.44f,h*0.55f,w*0.55f,h*0.72f,muted);
        c.drawLine(w*0.44f,h*0.55f,w*0.50f,h*0.42f,muted); c.drawLine(w*0.50f,h*0.42f,w*0.58f,h*0.42f,muted);
        head(c,w*0.43f,h*0.24f); body(c,w*0.43f,h*0.34f,w*0.46f,h*0.50f); body(c,w*0.46f,h*0.40f,w*0.56f,h*0.42f); body(c,w*0.46f,h*0.43f,w*0.34f,h*0.52f);
        body(c,w*0.46f,h*0.50f,w*0.39f,h*0.63f); body(c,w*0.46f,h*0.50f,w*0.51f,h*0.66f); arrow(c,w*0.67f,h*0.38f,w*0.67f,h*0.62f);
    }
    private void drawStretch(Canvas c,float w,float h){
        head(c,w*0.32f,h*0.23f); body(c,w*0.32f,h*0.33f,w*0.32f,h*0.58f); body(c,w*0.32f,h*0.40f,w*0.22f,h*0.32f); body(c,w*0.32f,h*0.40f,w*0.42f,h*0.30f);
        body(c,w*0.32f,h*0.58f,w*0.24f,h*0.80f); body(c,w*0.32f,h*0.58f,w*0.46f,h*0.76f); arrow(c,w*0.55f,h*0.30f,w*0.72f,h*0.22f);
    }
    private void drawSquat(Canvas c,float w,float h){
        head(c,w*0.36f,h*0.25f); body(c,w*0.36f,h*0.35f,w*0.36f,h*0.55f); body(c,w*0.36f,h*0.40f,w*0.22f,h*0.48f); body(c,w*0.36f,h*0.40f,w*0.50f,h*0.48f);
        body(c,w*0.36f,h*0.55f,w*0.24f,h*0.72f); body(c,w*0.24f,h*0.72f,w*0.16f,h*0.80f); body(c,w*0.36f,h*0.55f,w*0.48f,h*0.72f); body(c,w*0.48f,h*0.72f,w*0.58f,h*0.80f);
        arrow(c,w*0.70f,h*0.30f,w*0.70f,h*0.70f);
    }
    private void drawHinge(Canvas c,float w,float h){
        head(c,w*0.36f,h*0.24f); body(c,w*0.36f,h*0.34f,w*0.46f,h*0.50f); body(c,w*0.43f,h*0.44f,w*0.54f,h*0.44f); body(c,w*0.46f,h*0.50f,w*0.28f,h*0.72f); body(c,w*0.46f,h*0.50f,w*0.58f,h*0.78f);
        c.drawLine(w*0.56f,h*0.44f,w*0.56f,h*0.72f,white); c.drawLine(w*0.58f,h*0.44f,w*0.58f,h*0.72f,white); arrow(c,w*0.68f,h*0.34f,w*0.78f,h*0.54f);
    }
    private void drawLunge(Canvas c,float w,float h){
        head(c,w*0.38f,h*0.24f); body(c,w*0.38f,h*0.34f,w*0.38f,h*0.58f); body(c,w*0.38f,h*0.40f,w*0.24f,h*0.46f); body(c,w*0.38f,h*0.40f,w*0.52f,h*0.46f);
        body(c,w*0.38f,h*0.58f,w*0.26f,h*0.76f); body(c,w*0.26f,h*0.76f,w*0.16f,h*0.76f); body(c,w*0.38f,h*0.58f,w*0.52f,h*0.70f); body(c,w*0.52f,h*0.70f,w*0.62f,h*0.82f);
        arrow(c,w*0.72f,h*0.36f,w*0.62f,h*0.56f);
    }
    private void drawLegPress(Canvas c,float w,float h){
        machineBlock(c,w*0.10f,h*0.56f,w*0.34f,h*0.78f); machineBlock(c,w*0.60f,h*0.18f,w*0.80f,h*0.36f);
        c.drawLine(w*0.34f,h*0.56f,w*0.60f,h*0.36f,muted); c.drawLine(w*0.34f,h*0.78f,w*0.60f,h*0.36f,muted);
        head(c,w*0.30f,h*0.40f); body(c,w*0.30f,h*0.50f,w*0.22f,h*0.64f); body(c,w*0.22f,h*0.64f,w*0.14f,h*0.64f); body(c,w*0.22f,h*0.64f,w*0.28f,h*0.74f);
        body(c,w*0.22f,h*0.54f,w*0.40f,h*0.50f); body(c,w*0.40f,h*0.50f,w*0.56f,h*0.34f); arrow(c,w*0.58f,h*0.42f,w*0.72f,h*0.28f);
    }
    private void drawLatPulldown(Canvas c,float w,float h){
        machineBlock(c,w*0.62f,h*0.16f,w*0.76f,h*0.80f); c.drawLine(w*0.48f,h*0.20f,w*0.76f,h*0.20f,muted); c.drawLine(w*0.50f,h*0.20f,w*0.50f,h*0.34f,muted);
        c.drawLine(w*0.44f,h*0.34f,w*0.56f,h*0.34f,muted); head(c,w*0.34f,h*0.34f); body(c,w*0.34f,h*0.44f,w*0.34f,h*0.64f); body(c,w*0.34f,h*0.46f,w*0.28f,h*0.34f); body(c,w*0.34f,h*0.46f,w*0.40f,h*0.34f);
        body(c,w*0.34f,h*0.64f,w*0.26f,h*0.80f); body(c,w*0.34f,h*0.64f,w*0.42f,h*0.80f); arrow(c,w*0.50f,h*0.24f,w*0.50f,h*0.38f);
    }
    private void drawBenchPress(Canvas c,float w,float h){
        c.drawLine(w*0.18f,h*0.66f,w*0.58f,h*0.66f,muted); c.drawLine(w*0.26f,h*0.66f,w*0.26f,h*0.78f,muted); c.drawLine(w*0.50f,h*0.66f,w*0.50f,h*0.78f,muted);
        head(c,w*0.22f,h*0.52f); body(c,w*0.32f,h*0.52f,w*0.48f,h*0.52f); body(c,w*0.36f,h*0.52f,w*0.36f,h*0.64f); body(c,w*0.44f,h*0.52f,w*0.44f,h*0.64f); body(c,w*0.48f,h*0.52f,w*0.58f,h*0.46f); body(c,w*0.48f,h*0.52f,w*0.58f,h*0.58f);
        c.drawLine(w*0.58f,h*0.46f,w*0.72f,h*0.46f,white); c.drawLine(w*0.58f,h*0.58f,w*0.72f,h*0.58f,white); arrow(c,w*0.74f,h*0.60f,w*0.74f,h*0.44f);
    }
    private void drawRow(Canvas c,float w,float h){
        machineBlock(c,w*0.62f,h*0.24f,w*0.80f,h*0.76f); c.drawLine(w*0.52f,h*0.50f,w*0.62f,h*0.50f,muted);
        head(c,w*0.26f,h*0.34f); body(c,w*0.26f,h*0.44f,w*0.30f,h*0.62f); body(c,w*0.28f,h*0.48f,w*0.50f,h*0.50f); body(c,w*0.30f,h*0.62f,w*0.22f,h*0.80f); body(c,w*0.30f,h*0.62f,w*0.38f,h*0.80f); arrow(c,w*0.56f,h*0.50f,w*0.42f,h*0.50f);
    }
    private void drawDeadBug(Canvas c,float w,float h){
        head(c,w*0.24f,h*0.36f); body(c,w*0.34f,h*0.36f,w*0.56f,h*0.36f); body(c,w*0.44f,h*0.36f,w*0.60f,h*0.22f); body(c,w*0.44f,h*0.36f,w*0.64f,h*0.48f); body(c,w*0.50f,h*0.36f,w*0.66f,h*0.20f); body(c,w*0.50f,h*0.36f,w*0.66f,h*0.58f); arrow(c,w*0.74f,h*0.18f,w*0.86f,h*0.10f); arrow(c,w*0.74f,h*0.58f,w*0.86f,h*0.66f);
    }
    private void drawStepUp(Canvas c,float w,float h){
        machineBlock(c,w*0.54f,h*0.56f,w*0.78f,h*0.72f); head(c,w*0.32f,h*0.24f); body(c,w*0.32f,h*0.34f,w*0.32f,h*0.56f); body(c,w*0.32f,h*0.40f,w*0.22f,h*0.48f); body(c,w*0.32f,h*0.40f,w*0.42f,h*0.48f); body(c,w*0.32f,h*0.56f,w*0.44f,h*0.56f); body(c,w*0.44f,h*0.56f,w*0.60f,h*0.56f); body(c,w*0.32f,h*0.56f,w*0.24f,h*0.80f); arrow(c,w*0.48f,h*0.46f,w*0.58f,h*0.36f);
    }
    private void drawHipThrust(Canvas c,float w,float h){
        machineBlock(c,w*0.12f,h*0.58f,w*0.30f,h*0.72f); head(c,w*0.26f,h*0.46f); body(c,w*0.34f,h*0.46f,w*0.48f,h*0.52f); body(c,w*0.48f,h*0.52f,w*0.64f,h*0.52f); body(c,w*0.64f,h*0.52f,w*0.76f,h*0.62f); body(c,w*0.48f,h*0.52f,w*0.38f,h*0.72f); body(c,w*0.64f,h*0.52f,w*0.74f,h*0.72f); c.drawLine(w*0.44f,h*0.48f,w*0.68f,h*0.48f,white); arrow(c,w*0.52f,h*0.40f,w*0.62f,h*0.40f);
    }
    private void drawShoulderPress(Canvas c,float w,float h){
        machineBlock(c,w*0.16f,h*0.56f,w*0.40f,h*0.78f); head(c,w*0.30f,h*0.36f); body(c,w*0.30f,h*0.46f,w*0.30f,h*0.66f); body(c,w*0.30f,h*0.48f,w*0.22f,h*0.38f); body(c,w*0.30f,h*0.48f,w*0.38f,h*0.38f); body(c,w*0.30f,h*0.66f,w*0.22f,h*0.82f); body(c,w*0.30f,h*0.66f,w*0.38f,h*0.82f); c.drawLine(w*0.22f,h*0.38f,w*0.22f,h*0.24f,white); c.drawLine(w*0.38f,h*0.38f,w*0.38f,h*0.24f,white); arrow(c,w*0.22f,h*0.34f,w*0.22f,h*0.20f); arrow(c,w*0.38f,h*0.34f,w*0.38f,h*0.20f);
    }
    private void drawLegCurl(Canvas c,float w,float h){
        machineBlock(c,w*0.16f,h*0.56f,w*0.40f,h*0.76f); head(c,w*0.26f,h*0.40f); body(c,w*0.32f,h*0.46f,w*0.46f,h*0.54f); body(c,w*0.46f,h*0.54f,w*0.62f,h*0.54f); body(c,w*0.62f,h*0.54f,w*0.74f,h*0.64f); c.drawLine(w*0.72f,h*0.60f,w*0.72f,h*0.76f,white); arrow(c,w*0.76f,h*0.72f,w*0.70f,h*0.58f);
    }
    private void drawCarry(Canvas c,float w,float h){
        head(c,w*0.38f,h*0.24f); body(c,w*0.38f,h*0.34f,w*0.38f,h*0.58f); body(c,w*0.38f,h*0.40f,w*0.28f,h*0.54f); body(c,w*0.38f,h*0.40f,w*0.48f,h*0.54f); body(c,w*0.28f,h*0.54f,w*0.28f,h*0.72f); body(c,w*0.48f,h*0.54f,w*0.48f,h*0.72f); body(c,w*0.38f,h*0.58f,w*0.28f,h*0.82f); body(c,w*0.38f,h*0.58f,w*0.48f,h*0.82f); machineBlock(c,w*0.22f,h*0.72f,w*0.34f,h*0.82f); machineBlock(c,w*0.42f,h*0.72f,w*0.54f,h*0.82f); arrow(c,w*0.62f,h*0.50f,w*0.78f,h*0.50f);
    }
    private void drawPallof(Canvas c,float w,float h){
        machineBlock(c,w*0.72f,h*0.18f,w*0.82f,h*0.80f); head(c,w*0.34f,h*0.26f); body(c,w*0.34f,h*0.36f,w*0.34f,h*0.60f); body(c,w*0.34f,h*0.44f,w*0.50f,h*0.44f); body(c,w*0.50f,h*0.44f,w*0.62f,h*0.44f); body(c,w*0.34f,h*0.60f,w*0.26f,h*0.82f); body(c,w*0.34f,h*0.60f,w*0.42f,h*0.82f); c.drawLine(w*0.62f,h*0.44f,w*0.72f,h*0.44f,muted); arrow(c,w*0.54f,h*0.34f,w*0.64f,h*0.34f);
    }
    private void drawLateralRaise(Canvas c,float w,float h){
        head(c,w*0.36f,h*0.24f); body(c,w*0.36f,h*0.34f,w*0.36f,h*0.60f); body(c,w*0.36f,h*0.42f,w*0.20f,h*0.42f); body(c,w*0.36f,h*0.42f,w*0.52f,h*0.42f); body(c,w*0.36f,h*0.60f,w*0.28f,h*0.82f); body(c,w*0.36f,h*0.60f,w*0.44f,h*0.82f); c.drawCircle(w*0.20f,h*0.42f,dp(5),accent); c.drawCircle(w*0.52f,h*0.42f,dp(5),accent); arrow(c,w*0.12f,h*0.60f,w*0.20f,h*0.46f); arrow(c,w*0.60f,h*0.60f,w*0.52f,h*0.46f);
    }
    private void drawFacePull(Canvas c,float w,float h){
        machineBlock(c,w*0.74f,h*0.18f,w*0.84f,h*0.80f); head(c,w*0.30f,h*0.28f); body(c,w*0.30f,h*0.38f,w*0.30f,h*0.62f); body(c,w*0.30f,h*0.46f,w*0.44f,h*0.32f); body(c,w*0.30f,h*0.46f,w*0.44f,h*0.46f); c.drawLine(w*0.44f,h*0.32f,w*0.74f,h*0.28f,muted); c.drawLine(w*0.44f,h*0.46f,w*0.74f,h*0.46f,muted); body(c,w*0.30f,h*0.62f,w*0.22f,h*0.82f); body(c,w*0.30f,h*0.62f,w*0.38f,h*0.82f); arrow(c,w*0.62f,h*0.24f,w*0.50f,h*0.28f);
    }
    private void drawCurl(Canvas c,float w,float h){
        head(c,w*0.36f,h*0.24f); body(c,w*0.36f,h*0.34f,w*0.36f,h*0.60f); body(c,w*0.36f,h*0.42f,w*0.26f,h*0.58f); body(c,w*0.36f,h*0.42f,w*0.46f,h*0.58f); body(c,w*0.36f,h*0.60f,w*0.28f,h*0.82f); body(c,w*0.36f,h*0.60f,w*0.44f,h*0.82f); c.drawCircle(w*0.26f,h*0.58f,dp(5),accent); c.drawCircle(w*0.46f,h*0.58f,dp(5),accent); arrow(c,w*0.18f,h*0.62f,w*0.28f,h*0.52f); arrow(c,w*0.54f,h*0.62f,w*0.44f,h*0.52f);
    }
    private void drawPressdown(Canvas c,float w,float h){
        machineBlock(c,w*0.74f,h*0.18f,w*0.84f,h*0.80f); head(c,w*0.32f,h*0.24f); body(c,w*0.32f,h*0.34f,w*0.32f,h*0.60f); body(c,w*0.32f,h*0.42f,w*0.44f,h*0.42f); body(c,w*0.44f,h*0.42f,w*0.52f,h*0.60f); body(c,w*0.32f,h*0.60f,w*0.24f,h*0.82f); body(c,w*0.32f,h*0.60f,w*0.40f,h*0.82f); c.drawLine(w*0.52f,h*0.60f,w*0.74f,h*0.60f,muted); arrow(c,w*0.52f,h*0.46f,w*0.52f,h*0.62f);
    }
    private void drawBreathing(Canvas c,float w,float h){
        head(c,w*0.34f,h*0.24f); body(c,w*0.34f,h*0.34f,w*0.34f,h*0.60f); body(c,w*0.34f,h*0.42f,w*0.24f,h*0.48f); body(c,w*0.34f,h*0.42f,w*0.44f,h*0.48f); body(c,w*0.34f,h*0.60f,w*0.26f,h*0.82f); body(c,w*0.34f,h*0.60f,w*0.42f,h*0.82f); arrow(c,w*0.60f,h*0.36f,w*0.74f,h*0.30f); arrow(c,w*0.60f,h*0.46f,w*0.74f,h*0.52f);
    }
}
