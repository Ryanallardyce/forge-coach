package uk.co.forgecoach;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class ExerciseGuide {
    public static class Guide {
        public final String name, tagline, equipment, setup, movement, cues, commonErrors, alternative, diagramType, gifAsset, demoUrl;
        public final boolean isFallback;
        public Guide(String name,String tagline,String equipment,String setup,String movement,String cues,String commonErrors,String alternative,String diagramType,String gifAsset,String demoUrl,boolean isFallback){
            this.name=name;
            this.tagline=tagline;
            this.equipment=equipment;
            this.setup=setup;
            this.movement=movement;
            this.cues=cues;
            this.commonErrors=commonErrors;
            this.alternative=alternative;
            this.diagramType=diagramType;
            this.gifAsset=gifAsset;
            this.demoUrl=demoUrl;
            this.isFallback=isFallback;
        }
    }

    private static final Map<String,Guide> GUIDES=new HashMap<>();

    static {
        put("Fast walk or easy cycle","Warm-up cardio","Treadmill, walking area, or stationary bike","Choose a brisk but easy pace that raises your temperature without breathlessness.","Walk or pedal smoothly, keeping posture tall and shoulders relaxed.","Nose-breathe if possible. You should feel warmer, not fatigued.","Do not sprint or turn the warm-up into a workout.","Rowing machine at easy pace","bike","stationary bike exercise form");
        put("Hip hinge drill","Movement pattern drill","Bodyweight only or light dowel if available","Stand tall with soft knees and hands on hips or thighs.","Push hips backwards while keeping your spine neutral, then stand tall again.","Think 'hips back, chest proud, ribs down'.","Avoid rounding the low back or turning it into a squat.","Bodyweight good morning","hinge","hip hinge drill exercise");
        put("Bodyweight squats","Warm-up lower-body movement","Open floor space or bodyweight area","Stand feet about shoulder-width apart with toes slightly turned out.","Sit down between the hips, then drive back up to standing.","Keep knees tracking over toes and weight through mid-foot.","Do not let heels lift or knees collapse in.","Box squat to bench","squat","bodyweight squat form");
        put("Arm circles and shoulder rolls","Upper-body warm-up","Open floor space","Stand tall with arms out to the side or by your sides.","Perform controlled circles and shoulder rolls through a comfortable range.","Move smoothly and open the chest.","Do not force painful ranges.","Band shoulder warm-up","arm_circles","shoulder warm up mobility");
        put("Alternating reverse lunges","Single-leg warm-up and strength","Bodyweight space or light dumbbells if progressed","Stand tall with feet hip-width apart.","Step one leg backwards, lower under control, then return and alternate sides.","Front foot planted, chest up, light touch with back knee.","Avoid pushing the front knee too far inward or leaning heavily forward.","Static split squat","lunge","reverse lunge exercise form");
        put("Standing trunk rotations","Torso warm-up","Open floor space","Stand tall with soft knees and hands together in front of chest.","Rotate gently left and right through the upper body.","Move through a comfortable range and stay relaxed.","Do not twist aggressively through the low back.","Open-book mobility drill","trunk_rotation","standing trunk rotation mobility");
        put("Leg press","Machine lower-body strength","Leg press machine","Adjust the seat so knees start bent but not compressed into your chest. Feet go hip-to-shoulder width on the platform.","Unlock the sled, lower under control until thighs approach your comfortable depth, then press the platform away until legs are nearly straight.","Drive through the whole foot, keep knees tracking over toes, and keep the lower back against the pad.","Do not lock knees hard, bounce at the bottom, or let hips lift off the pad.","Goblet squat","machine_leg_press","leg press machine form");
        put("Lat pulldown","Machine back exercise","Lat pulldown machine with long bar","Set thigh pads firmly over the legs. Sit tall and grip the bar just outside shoulder width.","Pull the bar towards the top of your chest, squeezing elbows down and back, then return under control.","Lead with elbows, chest proud, and keep shoulders away from ears.","Do not yank with momentum or pull the bar behind your neck.","Assisted pull-up","pull_vertical","lat pulldown form");
        put("Dumbbell bench press","Upper-body push","Flat bench and a pair of dumbbells","Lie on the bench with feet planted and dumbbells at chest level.","Press dumbbells up over the chest, then lower with control until elbows come just below bench height if comfortable.","Wrists stacked over elbows, shoulder blades lightly tucked back, smooth tempo.","Avoid flaring elbows too wide or bouncing the weights.","Machine chest press","press_horizontal","dumbbell bench press form");
        put("Dumbbell Romanian deadlift","Posterior-chain strength","Pair of dumbbells and open floor space","Stand tall holding dumbbells in front of thighs with a soft bend in the knees.","Push hips back and lower the dumbbells down the thighs or shins until you feel the hamstrings load, then stand back up by driving hips forward.","Keep the dumbbells close, spine neutral, and neck relaxed.","Do not turn it into a squat or round through the back.","Cable pull-through","hinge","dumbbell romanian deadlift form");
        put("Seated cable row","Machine back row","Seated cable row station","Place feet on the platform, take the handle, and sit tall with arms extended.","Pull the handle towards the lower ribs while drawing elbows back, then return under control.","Stay tall, squeeze shoulder blades lightly together, and avoid shrugging.","Do not rock backwards to move the weight.","Chest-supported row","pull_horizontal","seated cable row form");
        put("Stationary bicycle · brisk","Conditioning cardio","Exercise bike","Adjust seat height so the knee stays slightly bent at the bottom of the pedal stroke.","Pedal at a brisk, controlled effort for the timed interval.","Tall posture, smooth cadence, controlled breathing.","Do not start so hard that you fade instantly.","Cross trainer","bike","stationary bike exercise form");
        put("Dead bug","Core stability","Exercise mat or floor space","Lie on your back with arms up and knees bent to 90 degrees.","Extend the opposite arm and leg slowly while keeping the low back gently pressed into the floor, then alternate.","Brace the trunk and move slowly.","Avoid arching the lower back.","Heel taps","core","dead bug exercise form");
        put("Half-kneeling hip flexor stretch","Mobility stretch","Mat or floor space","Kneel with one knee down and the other foot in front.","Tuck the pelvis under slightly and glide hips forward until you feel the front of the rear hip stretch.","Stay tall and squeeze the glute of the kneeling side.","Do not overarch the low back.","Standing hip flexor stretch","hip_flexor_stretch","hip flexor stretch");
        put("Hamstring stretch","Mobility stretch","Mat or bench","Place one heel forward with toes up or lie on the floor using a towel if preferred.","Lean or lift until you feel a comfortable stretch behind the thigh.","Long spine and gentle breathing.","Do not force range or bounce.","Seated hamstring stretch","hamstring_stretch","hamstring stretch");
        put("Doorway chest stretch","Upper-body mobility","Doorway or upright frame","Place forearm on the doorway with elbow around shoulder height.","Gently step through until you feel a stretch in the chest and front shoulder.","Keep the neck relaxed and ribs down.","Do not push into sharp shoulder pain.","Corner pec stretch","doorway_chest_stretch","doorway chest stretch");
        put("Calf stretch","Lower-leg mobility","Wall or step","Place hands on wall and one leg behind you with heel down.","Lean forward until the calf stretches, then repeat with a bent-knee variation if desired.","Keep rear heel grounded.","Do not bounce.","Step calf stretch","calf_stretch","calf stretch");
        put("Slow nasal breathing","Cooldown recovery","Quiet standing or seated space","Adopt a comfortable standing, kneeling, or seated position.","Breathe slowly in and out through the nose, letting heart rate settle.","Long, calm exhales.","Do not rush the cooldown.","Box breathing","breathing","box breathing technique");
        put("Alternating step-ups","Single-leg leg strength","Step-up box or bench, usually knee height or slightly below","Stand facing the step with the whole foot planted on top.","Drive through the lead leg to stand up, control the descent, then alternate sides.","Keep torso tall and control the lowering phase.","Avoid pushing too much off the trailing leg or crashing down.","Reverse lunges","step_up","step up exercise form");
        put("Chest-supported row","Back strength","Incline bench and dumbbells or chest-supported row machine","Lie chest-down on the support with feet stable and arms hanging.","Row elbows back and down, squeezing upper back, then lower under control.","Keep chest in contact with the pad and neck neutral.","Do not shrug or jerk the weights.","Seated cable row","pull_horizontal","chest supported row form");
        put("Hip thrust machine","Glute-focused strength","Hip thrust machine","Set shoulder or back support and pad position so your hips can move freely and feet are flat.","Lower the hips under control, then drive upward until hips are extended and glutes squeezed.","Ribs down, chin tucked slightly, push through heels.","Avoid hyperextending the low back at the top.","Barbell or smith-machine hip thrust","hip_thrust","hip thrust machine form");
        put("Incline dumbbell press","Upper chest / front shoulder press","Incline bench and dumbbells","Set the bench to a low-to-moderate incline and plant feet on the floor.","Press the dumbbells above the upper chest, then lower with control.","Shoulder blades tucked lightly back, wrists stacked, controlled tempo.","Avoid excessively steep incline or flaring elbows hard.","Machine incline press","press_horizontal","incline dumbbell press form");
        put("Seated shoulder press","Shoulder strength","Seated shoulder press machine or bench with back support and dumbbells","Sit upright with hands starting around shoulder level.","Press overhead until arms are extended, then lower smoothly.","Brace the trunk and keep shoulders down away from ears.","Do not overarch your back.","Dumbbell shoulder press","press_vertical","seated shoulder press form");
        put("Seated leg curl","Hamstring machine","Seated leg curl machine","Adjust the backrest, thigh pad and ankle pad so the machine lines up with your knee joint.","Curl the pad down by bending the knees, squeeze hamstrings, then return under control.","Keep hips down and control both directions.","Do not kick the weight up with momentum.","Lying leg curl","leg_curl","seated leg curl form");
        put("Farmer carry","Grip and trunk stability","Pair of dumbbells or kettlebells and open walking space","Choose two weights and stand tall with one in each hand.","Walk under control for the time or distance prescribed.","Shoulders down, ribs stacked, short controlled steps.","Do not lean excessively or let the weights bang around.","Single-arm suitcase carry","carry","farmer carry form");
        put("Pallof press","Anti-rotation core","Cable stack or resistance band anchored at chest height","Stand side-on to the cable or band and hold the handle at the chest.","Press straight out in front without letting the torso rotate, then bring it back.","Brace the mid-section and keep hips square.","Do not twist towards the stack.","Band Pallof hold","pallof","pallof press form");
        put("Stationary bike · steady hard","Aerobic finisher","Exercise bike","Set up as for other bike intervals with a slightly more challenging resistance.","Ride at a hard but sustainable pace for the interval.","Strong but controlled effort; you should work, not sprint out.","Do not start too hard and fade badly.","Cross trainer hard interval","bike","stationary bike interval workout");
        put("Standing calf raises","Calf strength","Bodyweight, dumbbells, or standing calf machine","Stand tall with feet hip-width apart, optionally using support for balance.","Rise onto the balls of the feet, squeeze calves, then lower under control.","Move through full range and pause briefly at the top.","Do not bounce quickly through the reps.","Seated calf raise","calf_raise","standing calf raise form");
        put("Light leg press","Leg maintenance","Leg press machine","Use the same machine as the main leg press but with a lighter, fresher effort.","Perform the same movement pattern as leg press, focusing on smooth repetitions rather than maximal loading.","Controlled tempo, leave reps in reserve.","Do not fatigue your legs heavily before the Saturday run.","Goblet squat","machine_leg_press","leg press machine form");
        put("Lat pulldown or assisted pull-up","Upper-back strength","Lat pulldown machine or assisted pull-up machine","Use whichever station is free and feels most confident for you.","For pulldown, pull the bar to the upper chest. For assisted pull-up, pull yourself up with the machine assistance set high enough to stay controlled.","Lead with elbows and keep the chest lifted.","Do not swing or jerk.","Seated cable row","pull_vertical","assisted pull up or lat pulldown form");
        put("Machine chest press","Machine upper-body push","Chest press machine","Adjust the seat so the handles start around mid-chest height.","Press the handles forward until arms are extended, then return under control.","Keep shoulders down and shoulder blades lightly set.","Do not shrug or let elbows flare wildly.","Dumbbell bench press","press_horizontal","machine chest press form");
        put("Cable pull-through (light)","Posterior-chain activation","Cable machine with rope attachment","Face away from the stack, with the rope passing through the legs, and step forward to create tension.","Hinge at the hips and then drive them through to stand tall.","Think 'hips back, hips through'. Keep arms as hooks.","Do not squat it or overarch at lockout.","Dumbbell Romanian deadlift","hinge","cable pull through form");
        put("Dumbbell lateral raises","Shoulder accessory","Pair of light dumbbells","Stand tall with dumbbells at the sides and a slight bend in the elbows.","Raise the arms out to the side until around shoulder height, then lower under control.","Lead with elbows and keep the movement smooth.","Avoid swinging or shrugging hard.","Cable lateral raise","lateral_raise","dumbbell lateral raise form");
        put("Cable face pull","Rear shoulder / upper-back accessory","Cable station with rope attachment set around face height","Hold the rope with thumbs towards you and step back to create tension.","Pull the rope towards the face while elbows flare out, then return under control.","Think 'pull apart and back'. Keep chest up.","Do not turn it into a low row or overload the movement.","Band face pull","face_pull","cable face pull form");
        put("Dumbbell biceps curl","Arm accessory","Pair of dumbbells","Stand tall with arms by your sides.","Curl the dumbbells up by bending the elbows, then lower under control.","Keep elbows close to your sides and avoid swinging.","Do not lean back to cheat the weight up.","Cable curl","curl","dumbbell biceps curl form");
        put("Rope triceps pressdown","Arm accessory","Cable station with rope attachment","Stand facing the cable with elbows tucked by your sides.","Push the rope down until arms are straight, then return under control.","Keep upper arms still and spread the rope slightly at the bottom.","Do not let elbows drift forward or shoulders hunch.","Straight-bar pressdown","pressdown","rope triceps pressdown form");
        put("Stationary bike · moderate effort","Low-impact conditioning","Exercise bike","Set the seat and resistance to a comfortable moderate challenge.","Pedal at a moderate pace that raises breathing but stays smooth.","Tall posture and consistent cadence.","Do not overdo it if legs are tired before the weekend run.","Cross trainer","bike","stationary bike form");
        put("Bike · easy spin","Recovery spin","Exercise bike","Use light resistance and a relaxed pace.","Pedal easily to flush the legs and begin cooling down.","Relax the shoulders and breathe steadily.","Do not push hard in this interval.","Walk cooldown","bike","easy bike recovery spin");
    }

    private static void put(String name,String tagline,String equipment,String setup,String movement,String cues,String commonErrors,String alternative,String diagramType,String demoQuery){
        GUIDES.put(name.toLowerCase(Locale.UK),new Guide(name,tagline,equipment,setup,movement,cues,commonErrors,alternative,diagramType,gif(diagramType),search(demoQuery),false));
    }

    private static String gif(String diagramType){
        if(diagramType==null || diagramType.trim().isEmpty()) diagramType = "generic";
        return "gifs/" + diagramType + ".gif";
    }

    public static Guide forExercise(String name){
        if(name==null || name.trim().isEmpty()) return fallback("Exercise");
        Guide exact=GUIDES.get(name.toLowerCase(Locale.UK));
        if(exact!=null) return exact;
        String normalised=name.toLowerCase(Locale.UK);
        for(Map.Entry<String,Guide> e: GUIDES.entrySet()){
            if(normalised.contains(e.getKey()) || e.getKey().contains(normalised)) return e.getValue();
        }
        return fallback(name);
    }

    private static String search(String q){
        return "https://www.youtube.com/results?search_query=" + q.trim().replace(" ", "+");
    }

    private static Guide fallback(String name){
        return new Guide(name,
                "General exercise guidance",
                "Use the machine, station, or free-weight area named in the exercise title.",
                "Set the machine so the moving joints line up comfortably and start with a conservative load.",
                "Move through a controlled range, keeping steady posture and tempo.",
                "Stay controlled, breathe steadily, and stop 1–3 reps or a few seconds before technique breaks down.",
                "Avoid chasing weight if you are unsure of the set-up or movement.",
                "Ask a member of gym staff to confirm the exact station if uncertain.",
                "generic",
                gif("generic"),
                search(name + " exercise form"),
                true);
    }
}
