package uk.co.forgecoach;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Movie;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

import java.io.IOException;
import java.io.InputStream;

public class GifView extends View {
    private Movie movie;
    private long movieStart = 0L;

    public GifView(Context context) { super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
    public GifView(Context context, AttributeSet attrs) { super(context, attrs); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }

    public void setAsset(String assetPath) {
        try (InputStream is = getContext().getAssets().open(assetPath)) {
            movie = Movie.decodeStream(is);
            movieStart = 0L;
            requestLayout();
            invalidate();
        } catch (IOException e) {
            movie = null;
            invalidate();
        }
    }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int desiredHeight = (int)(180 * getResources().getDisplayMetrics().density);
        if (movie != null && movie.width() > 0 && movie.height() > 0 && width > 0) {
            desiredHeight = (int) (movie.height() * (width / (float) movie.width()));
        }
        int resolvedHeight = resolveSize(desiredHeight, heightMeasureSpec);
        setMeasuredDimension(width, resolvedHeight);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (movie == null) return;
        long now = SystemClock.uptimeMillis();
        if (movieStart == 0L) movieStart = now;
        int dur = movie.duration();
        if (dur <= 0) dur = 1000;
        int relTime = (int)((now - movieStart) % dur);
        movie.setTime(relTime);
        float s = Math.min(getWidth() / (float)Math.max(1, movie.width()), getHeight() / (float)Math.max(1, movie.height()));
        float dx = (getWidth() - movie.width() * s) / 2f;
        float dy = (getHeight() - movie.height() * s) / 2f;
        canvas.save();
        canvas.translate(dx, dy);
        canvas.scale(s, s);
        movie.draw(canvas, 0, 0);
        canvas.restore();
        postInvalidateDelayed(85);
    }
}
