package uk.co.forgecoach;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Fetches public, non-personalised monthly workout plans over HTTPS. User data never uploads. */
public final class PlanSync {
    private PlanSync(){}
    // Becomes live when the user creates the repository and we publish the plan files there.
    public static final String DEFAULT_MANIFEST =
        "https://raw.githubusercontent.com/Ryanallardyce/forge-coach/main/plans/index.json";
    private static final ExecutorService WORK = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    public interface Callback { void onResult(boolean ok,String message); }

    static String manifestUrl(Context c) {
        return PlanStore.prefs(c).getString("plan_manifest_url",DEFAULT_MANIFEST);
    }
    static void setManifestUrl(Context c,String newUrl) throws Exception {
        URI uri = verifiedUrl(newUrl);
        if (!uri.getPath().endsWith(".json")) throw new Exception("The update link must end in .json");
        PlanStore.prefs(c).edit().putString("plan_manifest_url",uri.toString()).putLong("last_sync_attempt",0).apply();
    }
    static boolean isDue(Context c) {
        long last = PlanStore.prefs(c).getLong("last_sync_attempt",0);
        return System.currentTimeMillis()-last >= 24L*60*60*1000;
    }
    public static void check(Context context, Callback callback) {
        Context c=context.getApplicationContext();
        String link=manifestUrl(c);
        PlanStore.prefs(c).edit().putLong("last_sync_attempt",System.currentTimeMillis()).apply();
        WORK.execute(()->{
            boolean ok=false;String message;
            try {
                URI base=verifiedUrl(link);
                JSONObject catalog=new JSONObject(fetch(base.toString(),32_000));
                if(catalog.getInt("schemaVersion")!=1) throw new Exception("Unsupported update list format");
                JSONArray records=catalog.getJSONArray("plans");
                if(records.length()>24) throw new Exception("Too many monthly plans in update list");
                List<String> imported=new ArrayList<>();
                for(int i=0;i<records.length();i++){
                    JSONObject record=records.getJSONObject(i);
                    String month=record.getString("month");
                    String filename=record.getString("file");
                    String expectedHash=record.getString("sha256").toLowerCase(Locale.ROOT);
                    if(!month.matches("20[0-9]{2}-(0[1-9]|1[0-2])") ||
                        !filename.equals(month+".json") || !expectedHash.matches("[a-f0-9]{64}"))
                        throw new Exception("Invalid entry in update list");
                    URI target=base.resolve(filename);
                    if(!verifiedUrl(target.toString()).getHost().equalsIgnoreCase(base.getHost()))
                        throw new Exception("Plan source changed host unexpectedly");
                    String content=fetch(target.toString(),500_000);
                    if(!hexHash(content.getBytes(StandardCharsets.UTF_8)).equals(expectedHash))
                        throw new Exception("The "+month+" plan did not pass its integrity check");
                    if(!PlanStore.validate(content).equals(month))throw new Exception("Plan month mismatch");
                    // Plan remains offline and local after download.
                    PlanStore.upsertPlan(c,content,false);
                    imported.add(month);
                }
                // Never change active plan while a workout is running.
                if(WorkoutService.latest==null || !WorkoutService.latest.active)
                    PlanStore.selectNewestStartedPlan(c);
                message=imported.isEmpty()?"No plans in the update list":"Plans available offline: "+String.join(", ",imported);
                ok=true;
                PlanStore.prefs(c).edit().putString("last_sync_result",message).apply();
            }catch(Exception e){message="Monthly plans are not yet available online: "+e.getMessage();}
            final boolean success=ok;final String feedback=message;
            MAIN.post(()->callback.onResult(success,feedback));
        });
    }
    private static URI verifiedUrl(String raw) throws Exception {
        URI uri=new URI(raw.trim());
        if(!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost()==null ||
            uri.getUserInfo()!=null || uri.getFragment()!=null || uri.getPort()!=-1)
            throw new Exception("Only public HTTPS update links are supported");
        return uri;
    }
    private static String fetch(String url,int limit) throws Exception {
        HttpURLConnection con=(HttpURLConnection)new URL(url).openConnection();
        con.setConnectTimeout(12000);con.setReadTimeout(12000);
        con.setRequestProperty("Accept","application/json");
        con.setInstanceFollowRedirects(false);
        try {
            int status=con.getResponseCode();
            if(status!=200) throw new Exception("HTTP "+status+" for "+new URL(url).getPath());
            try(InputStream in=con.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] buf=new byte[8192];int n,total=0;
                while((n=in.read(buf))!=-1){total+=n;if(total>limit)throw new Exception("Update file exceeds size limit");out.write(buf,0,n);}
                return new String(out.toByteArray(),StandardCharsets.UTF_8);
            }
        }finally{con.disconnect();}
    }
    private static String hexHash(byte[] input) throws Exception {
        byte[] digest=MessageDigest.getInstance("SHA-256").digest(input);
        StringBuilder s=new StringBuilder();for(byte b:digest)s.append(String.format(Locale.ROOT,"%02x",b&255));
        return s.toString();
    }
}
