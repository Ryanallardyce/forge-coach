package uk.co.forgecoach;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public final class WorkoutEngine {
    private WorkoutEngine() {}
    public static final class Step {
        public final String phase, name, cue, next, block;
        public final int seconds, round, rounds;
        public final boolean switchSides;
        Step(String phase,String name,String cue,String next,String block,int seconds,int round,int rounds,boolean sides){
            this.phase=phase;this.name=name;this.cue=cue;this.next=next;this.block=block;
            this.seconds=seconds;this.round=round;this.rounds=rounds;this.switchSides=sides;
        }
    }
    public static List<Step> make(JSONObject session,JSONObject week) throws JSONException {
        List<Step> out=new ArrayList<>();
        JSONArray blocks=session.getJSONArray("blocks");
        for(int bi=0;bi<blocks.length();bi++) {
            JSONObject b=blocks.getJSONObject(bi);
            String kind=b.getString("kind");
            int originalRounds=b.getInt("rounds");
            int delta=kind.equals("conditioning")?week.optInt("conditioningRoundDelta"):
                    (kind.equals("strength")||kind.equals("accessory"))?week.optInt("roundDelta"):0;
            int rounds=Math.max(1,Math.min(8,originalRounds+delta));
            JSONArray stations=b.getJSONArray("stations");
            String block=b.optString("title","");
            for(int r=1;r<=rounds;r++) {
                for(int i=0;i<stations.length();i++) {
                    JSONObject s=stations.getJSONObject(i);
                    String name=s.getString("name"), cue=s.optString("cue","");
                    String lc=cue.toLowerCase();
                    boolean sides=lc.contains("each side")||lc.contains("per side")||lc.contains("switch sides");
                    out.add(new Step("WORK",name,cue,"",block,s.getInt("seconds"),r,rounds,sides));
                    if(i<stations.length()-1) {
                        int t=b.getInt("stationTransitionSeconds");
                        if(t>0) out.add(new Step("CHANGE","Change station","Get equipment ready",stations.getJSONObject(i+1).getString("name"),block,t,r,rounds,false));
                    } else if(r<rounds) {
                        int t=b.getInt("restBetweenRoundsSeconds");
                        if(t>0) out.add(new Step("REST","Recover between rounds","Breathe, recover and reset",stations.getJSONObject(0).getString("name"),block,t,r,rounds,false));
                    }
                }
            }
            if(bi<blocks.length()-1) {
                int t=b.getInt("blockTransitionSeconds");
                if(t>0){
                    JSONObject next=blocks.getJSONObject(bi+1);
                    out.add(new Step("SETUP","Set up next block",next.optString("title",""),next.getJSONArray("stations").getJSONObject(0).getString("name"),block,t,0,0,false));
                }
            }
        }
        if(out.isEmpty()) throw new JSONException("Session has no intervals.");
        return out;
    }
    public static int duration(List<Step> steps) {
        int t=0;for(Step s:steps) t+=s.seconds;return t;
    }
    public static String clock(int sec) {return String.format(java.util.Locale.UK,"%02d:%02d",sec/60,sec%60);}
}
