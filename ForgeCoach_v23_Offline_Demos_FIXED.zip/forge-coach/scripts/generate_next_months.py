"""Illustrative December/January drafts; review progression before using."""
from pathlib import Path
import copy,json
folder=Path(__file__).resolve().parents[1]
base=json.loads((folder/'app/src/main/assets/default-plan.json').read_text())

for month, date, label in [
    ('2026-12','2026-12-07','December 2026 · Progressive strength and conditioning'),
    ('2027-01','2027-01-04','January 2027 · Full-body progression and mobility'),
]:
    d=copy.deepcopy(base)
    d['planId']='forge-'+month
    d['month']=month;d['startDate']=date;d['title']=label
    d['description']='DRAFT only. Review previous block before publishing; protect Tuesday and Saturday running days.'
    for s in d['sessions']:
        for b in s['blocks']:
            if b['kind']=='strength':
                b['restBetweenRoundsSeconds']=95 if month=='2026-12' else 100
                for ex in b['stations']:ex['seconds']=50
            if b['kind']=='accessory':
                b['restBetweenRoundsSeconds']=70
                for ex in b['stations']:ex['seconds']=45
            if b['kind']=='conditioning' and month=='2027-01':
                for ex in b['stations']:
                    if 'bike' in ex['name'].lower() and ex['seconds']>=35:ex['seconds']=40
    if month=='2027-01':
        # Maintain main movement patterns: only minor accessory rotation.
        changes={'Cable face pull':('Reverse pec deck','Lead with elbows; keep neck relaxed.'),
                 'Dumbbell biceps curl':('Alternating hammer curl','Avoid swinging; wrists neutral.'),
                 'Alternating step-ups':('Reverse lunge (supported)','Slow controlled stepping; alternate sides.')}
        for s in d['sessions']:
            for b in s['blocks']:
                for ex in b['stations']:
                    if ex['name'] in changes:
                        ex['name'],ex['cue']=changes[ex['name']]
    d['progression']=[
        {'week':1,'label':'Technique and load calibration','roundDelta':0,'conditioningRoundDelta':-1,'intensity':'RPE 7; controlled tempo, start conservatively'},
        {'week':2,'label':'Progressive overload','roundDelta':0,'conditioningRoundDelta':0,'intensity':'RPE 7–8; increase resistance only with full control'},
        {'week':3,'label':'Consolidate performance','roundDelta':0,'conditioningRoundDelta':0,'intensity':'RPE 7–8; aim better control or marginally higher load'},
        {'week':4,'label':'Deload/recovery','roundDelta':-1,'conditioningRoundDelta':-1,'intensity':'RPE 6–7; prioritise technique and recovery'},
    ]
    out=folder/('Forge_Coach_'+month+'.json')
    out.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
    print(out)
