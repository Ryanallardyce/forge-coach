#!/usr/bin/env python3
"""Publish a reviewed monthly plan into the public, read-only programme feed.
Run: python3 scripts/publish_plan.py Forge_Coach_2026-12.json
"""
import sys, json, pathlib, hashlib, datetime
base=pathlib.Path(__file__).resolve().parents[1]
if len(sys.argv)!=2:raise SystemExit('Usage: python3 scripts/publish_plan.py <reviewed-plan.json>')
p=pathlib.Path(sys.argv[1])
if not p.is_absolute():p=base/p
raw=p.read_bytes();obj=json.loads(raw)
assert obj['schemaVersion']==2
month=obj['month'];start=datetime.date.fromisoformat(obj['startDate'])
assert start.weekday()==0,'Training block must start on a Monday'
assert start.strftime('%Y-%m')==month
assert len(obj['sessions'])==3
out=base/'plans';out.mkdir(exist_ok=True)
(out/(month+'.json')).write_bytes(raw)
index=out/'index.json'
meta=json.loads(index.read_text())
recs=[x for x in meta.get('plans',[]) if x['month']!=month]
recs.append({'month':month,'file':month+'.json','sha256':hashlib.sha256(raw).hexdigest()})
meta['plans']=sorted(recs,key=lambda x:x['month']);meta['latestMonth']=meta['plans'][-1]['month']
index.write_text(json.dumps(meta,indent=2)+'\n')
print(f'Published {month}. Commit both plans/index.json and plans/{month}.json to GitHub. The app will fetch them on next sync.')
