"""Check the complete public update feed against its plan files, schedule and SHA256 digests."""
import json,hashlib,pathlib,datetime,re
base=pathlib.Path(__file__).resolve().parents[1]
feed=json.loads((base/'plans/index.json').read_text())
assert feed['schemaVersion']==1
assert feed['plans']
for entry in feed['plans']:
    month=entry['month'];assert re.fullmatch(r'20\d\d-(0[1-9]|1[0-2])',month)
    assert entry['file']==month+'.json'
    raw=(base/'plans'/entry['file']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==entry['sha256']
    doc=json.loads(raw)
    assert doc['month']==month and doc['schemaVersion']==2
    assert datetime.date.fromisoformat(doc['startDate']).weekday()==0
    assert [d['day'] for d in doc['schedule'] if d['type']=='run']==['Tuesday','Saturday']
    assert [(d['day'],d['sessionId']) for d in doc['schedule'] if d['type']=='gym']==[('Monday','A'),('Wednesday','B'),('Friday','C')]
    print(month,'feed integrity and weekly schedule PASS')
