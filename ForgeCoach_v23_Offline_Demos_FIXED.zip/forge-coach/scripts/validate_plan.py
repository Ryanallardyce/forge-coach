#!/usr/bin/env python3
"""Offline structure and timing test for Forge Coach v2 monthly plan files."""
import json, pathlib, re, sys, datetime

VALID={'warmup','strength','accessory','conditioning','mobility'}

def validate(path):
    plan=json.loads(pathlib.Path(path).read_text(encoding='utf8'))
    assert plan['schemaVersion']==2
    assert re.fullmatch(r'20\d\d-(0[1-9]|1[0-2])',plan['month'])
    assert datetime.date.fromisoformat(plan['startDate']).strftime('%Y-%m')==plan['month']
    assert [s['id'] for s in plan['sessions']]==['A','B','C']
    assert [w['week'] for w in plan['progression']]==[1,2,3,4]
    for s in plan['sessions']:
        assert s['blocks']
        for week in plan['progression']:
            timeline=[]
            for i,b in enumerate(s['blocks']):
                assert b['kind'] in VALID
                assert 1<=b['rounds']<=8
                stations=b['stations'];assert 1<=len(stations)<=15
                for key in ('stationTransitionSeconds','restBetweenRoundsSeconds','blockTransitionSeconds'):
                    assert 0<=b[key]<=300, (path,s['id'],key)
                for ex in stations:
                    assert ex['name'] and 10<=ex['seconds']<=600
                delta=week.get('conditioningRoundDelta',0) if b['kind']=='conditioning' else week.get('roundDelta',0) if b['kind'] in ('strength','accessory') else 0
                rounds=max(1,min(8,b['rounds']+delta))
                for r in range(rounds):
                    for j,ex in enumerate(stations):
                        timeline.append(('WORK',ex['name'],ex['seconds']))
                        if j<len(stations)-1 and b['stationTransitionSeconds']>0:
                            timeline.append(('CHANGE',stations[j+1]['name'],b['stationTransitionSeconds']))
                        elif j==len(stations)-1 and r<rounds-1 and b['restBetweenRoundsSeconds']>0:
                            timeline.append(('REST',stations[0]['name'],b['restBetweenRoundsSeconds']))
                if i<len(s['blocks'])-1 and b['blockTransitionSeconds']>0:
                    timeline.append(('SETUP',s['blocks'][i+1]['title'],b['blockTransitionSeconds']))
            total=sum(t for _,_,t in timeline)
            assert len(timeline)>0 and 20*60<=total<=70*60, (s['id'],week['week'],total)
            assert all(t>=1 for _,_,t in timeline)
            print(f"{plan['month']}  Session {s['id']}  Week {week['week']}: {len(timeline)} transitions, {total//60}:{total%60:02d} total, PASS")

if __name__=='__main__':
    for f in sys.argv[1:]:validate(f)
